# ZJ Comfy Studio v0.3.10

独立本地生成 App：React + TypeScript → FastAPI → 已有 ComfyUI。
沿用 ZJ AI Film 镜头台的 Flame 配色、面板与预览器。

## 网页镜头台：安装与配对（v0.3）

1. 保持已有 ComfyUI 运行。如果旧版 Studio 正在运行，先在其终端按 Ctrl+C；不要关闭 ComfyUI。
2. 将新 ZIP 完整解压，双击 **install.cmd**。脚本优先使用现有 Python 3.10–3.13；找不到时尝试通过 Python 安装管理器或 winget 安装 Python 3.12。
3. 安装到 `%LOCALAPPDATA%\ZJComfyStudio`，建立桌面快捷方式并注册 `zjcomfystudio://open`。不需要管理员权限，不修改 ComfyUI 环境。
4. 启动后，在 Studio 顶栏点击 **连接网页镜头台**（`http://127.0.0.1:8765/connect`）。点击 **取得一次性配对码**。
5. 回到镜头台「生成工作台 → 本机生成」，点击检测，将 8 位码填入并配对。如浏览器询问是否允许访问本机，请允许。
6. 先在自由生图中填写中文或英文提示词，使用官方完整 Krea 2、1 MP（方形 1024×1024）、8 steps、提示词增强开启进行测试。开始生成后自动提交任务、回传图片，仍需审核采用。

网页连接只支持已确认的网站来源。配对码有效期五分钟、只能使用一次；可在本机连接页撤销授权。浏览器中只保存绑定本机与来源的助手令牌，不保存云端桥接密钥。

第一版网页接入支持文字生图、API 工作流及其已有 LoRA 节点。参考图片和独立后处理仍使用外部手动流程，不能假装执行。

保持网页打开可自动回传。关闭网页后，已提交的本机任务继续运行；回到生成工作台并恢复连接后，会检查保存的任务并回收结果。清除网站数据后需重新配对；换电脑不能接管原电脑任务。

安装脚本是可审阅的 Windows 脚本安装包，尚未提供签名 EXE。未在本环境运行 Windows、GPU 或浏览器交互测试。

升级不搬动原 v0.1 文件夹中的 data。如果需要旧的独立 Studio 历史，请在两个 Studio 都关闭时，将旧 data 文件夹备份后复制到新安装目录。网页已保存的任务记录不依赖这一步。

## 官方完整 Krea 2 工作流（v0.3）

网页默认使用完整官方能力：本地 TextGenerate 提示词增强、ResolutionSelector、风格 LoRA 开关和触发词、Seed、8-step 采样、SaveImage。默认增强开启，LoRA 关闭，1 MP 方形。2 MP 是像素总量，方形按官方节点算成 1448×1448，不等于 2048×2048。

`workflows/krea2-official-full.json` 是固定版本的官方原始子图；来源和 SHA256 见 `krea2-official-source.json`。网页会将它明确映射为 API 执行图，并仅按用户开关跳过未启用的增强／LoRA 分支，以免未安装但关闭的 LoRA 阻止运行。不会静默关闭增强或降低分辨率。

每条网页记录保存源版本、原始提示词、实际 Seed、官方参数、执行图；PNG 元数据带本次原生子图。网页可下载本次配置后的完整原生工作流，用于 ComfyUI 对照。

官方 PreviewAny 返回的实际文本会随结果回收，追加启用的风格触发词后显示为生成用提示词。运行时没有返回文本则明确显示未回收，不能编造。

TextGenerate、ResolutionSelector 等核心节点缺失时明确报错，请按官方教程更新 ComfyUI。开启增强增加本机计算与显存负担，4070 12GB 仍需实机验证；0.5 MP 是用户主动选择的低显存测试预设，不是官方默认。

独立 Studio 仍保留早期基础测试工作流；网页工作台的默认入口已切换为官方完整流程。

## 独立运行：第一次使用

1. 将 ZIP **完整解压**到固定文件夹，例如 `D:\ZJ\zj-comfy-studio`。不要在 ZIP 内直接运行。
2. 先启动你原来的 ComfyUI，确认浏览器能打开 `http://127.0.0.1:8188`。
3. 双击 **start.bat**。第一次会在此文件夹建立独立 Python 环境并安装依赖，需要联网。使用现有 Python 3.12；无需重装 ComfyUI、下载模型或安装 Node.js。
4. 浏览器自动打开 `http://127.0.0.1:8765`。点击右上角 **ComfyUI 未连接 → 检测并保存**。
5. 选择左侧 **Krea 2 Turbo · 基础文生图**，在右侧确认模型文件、提示词及尺寸，再点 **开始生成**。

保留启动终端。`Ctrl+C` 结束 Studio；ComfyUI 独立运行。
如启动失败，终端会保留错误，便于反馈。Python 不在 PATH 时，安装 Python 3.12 并勾选 Add Python to PATH。

## 第一次真实出图测试

- 使用你已经在 ComfyUI 跑通的工作流最稳妥。ComfyUI 选择「文件 → 导出（API）」JSON，再拖到 Studio 中央或点击「导入」。
- 内置 Krea 2 工作流是官方模板基础节点的精简版本：关闭提示词扩写，不含 API 节点或额外风格 LoRA，默认 **768×768、8 steps、CFG 1、Euler、Simple**。
- 需要 `krea2_turbo_fp8_scaled.safetensors`、`qwen3vl_4b_fp8_scaled.safetensors`、`qwen_image_vae.safetensors`，以及支持 `CLIPLoader type=krea2` 的 ComfyUI。模型选单来自你运行中的 ComfyUI，不会假装模型已安装。
- 生成前会检查节点和模型文件，缺少时明确列出问题，不创建假成功任务。
- RTX 4070 12GB 尚未实机验证。768px 是起测值，不是显存保证；OOM 时保留错误记录，可降低尺寸或调整你现有 ComfyUI 的显存配置再试。
- Studio 独立界面当前仍直接导入 **API JSON**。镜头台工作流中心可把已验证的 UI 画布转换为 API prompt 后通过配对桥提交；无法确认的自定义控件不会猜测转换。

## 界面操作

| 区域 | 操作 |
| --- | --- |
| 左侧工作流 | 导入、搜索、选择；工作流中心可导出和移除 |
| Viewer | 滚轮缩放、拖动平移、F 适应、1:1、A/B 并排与切换、双击最大化 |
| Inspector | 提示词、尺寸、Seed、采样参数、模型文件、已有 LoRA 与强度 |
| Reel | 点击预览；Ctrl 多选；Shift 范围选；右键菜单；双击恢复参数 |
| 任务 | 队列状态、当前节点采样进度、取消、载入参数后重试 |
| 结果 | 下载原图、导出完整记录、批量删除记录及 Studio 图片副本 |
| 布局 | 拖动左右／底部分隔条；双击分隔条重置；自动记住尺寸 |

参考图仅对包含 `LoadImage` 的工作流生效。上传会传入已有 ComfyUI 输入目录并绑定参数；基础文生图不会偷偷使用图片。

LoRA 叠加使用 `LoraLoaderModelOnly`，可指定要接入的模型输入。兼容性由模型决定；需要文本编码器 LoRA 时，请导入包含 `LoraLoader` 的工作流，在参数区编辑其强度。风格触发词需写入提示词。

高清放大可作为独立 API 工作流导入，使用相同的队列与结果机制。首版回收 `SaveImage` 的输出图片，不回收视频。

## 数据与恢复

- `data/studio.sqlite3`：连接、工作流、完整生成记录。
- `data/results/`：Studio 下载保存的结果副本。
- 每条记录保留原工作流、版本哈希、最终提交图、实际 Seed、LoRA、参数、设备地址及镜头台关联 ID。
- 程序重启后会核对 ComfyUI 队列和历史，恢复尚未结束的任务，不会自动重送。
- 提交超时会标记「提交待核对」；系统用任务标记寻找已接受的请求，避免重复生成。若 ComfyUI 历史已清空且提交结果无法确认，需要在 ComfyUI 人工核对。确认无对应任务后，可点击「核对后结束记录」解除待核对状态。
- **删除**会清理 Studio 记录和结果副本。ComfyUI 的原始输出和输入参考图不自动删除，避免破坏已有工作流。
- 换电脑时备份整个 `data` 文件夹，并分别准备 ComfyUI、节点和模型。Git 不包含数据与模型。
- 当前节点进度来自 WebSocket；连接断开时仍通过 HTTP 检查队列和历史。节点采样百分比不是整条工作流预计完成百分比。

## 镜头台整合边界

独立启动已实现。关联字段 `projectId / shotId / assetId / lookId / referenceSetId` 随记录保存。
v0.2 已加入网页来源配对、网页任务提交与图片回传。网页通过本机浏览器访问已配对助手，云端服务不直接连接 localhost。尚未实现跨电脑调度、后台云端回传或桌面原生安装壳。

独立 App 仅监听 `127.0.0.1:8765`，同源界面可管理 Studio；跨域网页仅能通过配对后的 /bridge 接口访问自己的网页任务。不要用 `0.0.0.0` 对外暴露。API 合约和整合说明见 `INTEGRATION.md`。

## 开发与验证

交付包附已构建前端，运行无需 Node.js。

```bash
python -m venv .venv
# Windows: .venv\Scripts\python -m pip install -r requirements.txt
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python scripts/launch.py
```

修改前端后需重新构建（Node.js 22.13+）：

```bash
cd frontend
npm install
npm run build
```

测试：

```bash
python -m pip install pytest
python -m pytest -q
```

接口测试使用模拟 ComfyUI，覆盖持久化、队列、取消、结果下载、断线／重启恢复和错误路径。**不等于 Krea 2 在你的 GPU 上已经出图成功。** 本次未运行浏览器交互 QA、Windows 实机和 GPU 实测。

## 代码来源与版本管理

- Viewer 与 viewer-transform 复用现有镜头台源代码。
- Flame design tokens 与面板规则来自镜头台 `app/flame-system.css`。
- 这是独立工程中的同版组件快照。后续合入镜头台时将其提取为共享包，避免分别改视觉标准。
- 官方 Krea 2 模板：[Comfy-Org/workflow_templates](https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_krea2_turbo_t2i.json)。`workflows/krea2_official_ui.json` 留存官方源模板；`krea2_turbo_api.json` 为本 App 整理的基础执行版。
- ComfyUI API 参考：[官方 API 示例](https://github.com/Comfy-Org/ComfyUI/tree/master/script_examples)；模型来源：[Krea 官方仓库](https://github.com/krea-ai/krea-2)。模型及上游代码许可分别以原项目为准。
- 工程已准备 `.gitignore`。本次 GitHub 连接未返回可访问仓库，且当前工具不能创建仓库，**尚未推送 GitHub**。下载包包含完整源码，确定目标仓库后即可同步。

## Monitor 对比操作（v0.3.10）

并排 A/B 默认独立缩放和平移。点击或滚轮操作会激活对应窗口；底部适应、1:1 和缩放比例跟随当前窗口。开启联动才同步视图操作。1:1 按每张图自身尺寸计算。A 图片导航保持 B 对比图固定。切换模式按住空格查看 B；快捷键只在 Monitor 内生效。

## 程序更新（v0.3.10）

保留 Studio 内「检查更新 → 更新并重启」。读取程序内 update-source.json 指定的公开 GitHub 发布仓库中的 JSON 和 ZIP，支持 Windows 系统代理设置。客户端不使用 GitHub Token。网页传包只作备用入口。

下载后校验来源、版本、大小和 SHA-256；任务未结束不重启；程序文件先暂存，交给原启动器备份、替换及健康检查，失败尝试回滚。data、.venv、配对、ComfyUI 和模型目录保留。依赖改变需使用安装包。Windows 实际更新仍需实机验证。

发布前需配置确实存在且可写的公开仓库，然后运行 `python scripts/package-companion.py --release-base https://raw.githubusercontent.com/OWNER/REPO/BRANCH/windows`。将生成的 ZIP 和 studio-release.json 上传同一仓库目录，先上传带版本号 ZIP，再更新清单；验证匿名下载、文件大小及哈希后才能发放安装包。客户端固定使用该目录，后续发布保留旧版 ZIP。

未配置源时打包器拒绝生产发布；程序明确显示「更新发布源尚未配置」，不会伪报最新版或改用站点下载。`--review-output` 仅生成未配置的内部检查包，不可当作正式版本发放。
