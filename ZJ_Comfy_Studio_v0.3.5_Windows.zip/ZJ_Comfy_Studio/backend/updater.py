"""Fixed-origin releases; stage first, then let the owning launcher restart Studio."""
import hashlib
import io
from urllib.parse import urlsplit
import urllib.request
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile
import time
import zipfile

VERSION = '0.3.5'
SITE = 'https://ai-film-shot-studio.chun77129.chatgpt.site'
MANAGED = {'backend', 'scripts', 'frontend', 'workflows', 'tests', 'requirements.txt', 'README.md', 'start.bat', 'install.cmd', 'UI_BASELINE.json', 'INTEGRATION.md', 'update-source.json'}
MAX_BYTES = 50 * 1024 * 1024



def load_source(root):
    path = root / 'update-source.json'
    source = json.loads(path.read_text('utf-8')) if path.exists() else {}
    base = source.get('packageBase', '')
    manifest = source.get('manifestUrl', '')
    if not base and not manifest:
        return None
    parsed = urlsplit(base)
    if parsed.scheme != 'https' or parsed.hostname != 'raw.githubusercontent.com' or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.port or len(parsed.path.strip('/').split('/')) < 3 or manifest != base + '/studio-release.json':
        raise ValueError('更新发布源配置无效')
    return {'packageBase': base, 'manifestUrl': manifest}


def download_public(url, limit):
    # urllib uses the Windows system proxy settings, where configured.
    class RestrictedRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            if urlsplit(newurl).scheme != 'https' or urlsplit(newurl).hostname != urlsplit(url).hostname:
                raise ValueError('更新源发生了未授权重定向')
            return super().redirect_request(req, fp, code, msg, headers, newurl)
    opener = urllib.request.build_opener(RestrictedRedirect())
    request = urllib.request.Request(url, headers={'User-Agent': 'ZJ-Comfy-Studio/' + VERSION, 'Cache-Control': 'no-cache'})
    with opener.open(request, timeout=60) as response:
        body = response.read(limit + 1)
        if len(body) > limit:
            raise ValueError('更新下载内容过大')
        return body

def version(value):
    if not isinstance(value, str) or not re.fullmatch(r'\d+\.\d+\.\d+', value):
        raise ValueError('更新版本号无效')
    return tuple(map(int, value.split('.')))


def validate_release(value, source=None):
    version(value.get('version'))
    if not re.fullmatch(r'[a-f0-9]{64}', value.get('sha256', '')):
        raise ValueError('更新校验信息无效')
    filename = '/ZJ_Comfy_Studio_v' + value['version'] + '_Windows.zip'
    allowed = {SITE + '/downloads' + filename}
    if source:
        allowed.add(source['packageBase'] + filename)
    if value.get('url') not in allowed:
        raise ValueError('更新来源无效')
    if not isinstance(value.get('size'), int) or not 0 < value['size'] <= MAX_BYTES:
        raise ValueError('更新包大小无效')
    return value


def stage(root, archive, release):
    validate_release(release, load_source(root))
    if version(release['version']) <= version(VERSION):
        raise ValueError('当前已是最新版本')
    if archive.stat().st_size != release['size'] or hashlib.sha256(archive.read_bytes()).hexdigest() != release['sha256']:
        raise ValueError('更新包校验失败，当前版本未更改')
    updates = root / '.updates'
    updates.mkdir(exist_ok=True)
    destination = Path(tempfile.mkdtemp(prefix='staged-', dir=updates))
    try:
        with zipfile.ZipFile(archive) as package:
            total = 0
            seen = set()
            for item in package.infolist():
                path = PurePosixPath(item.filename)
                if '\\' in item.filename or path.is_absolute() or '..' in path.parts or len(path.parts) < 2 or path.parts[0] != 'ZJ_Comfy_Studio':
                    raise ValueError('更新包路径无效')
                relative = path.parts[1:]
                if relative[0] not in MANAGED or any(':' in p for p in relative) or (item.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError('更新包包含非程序文件')
                if item.is_dir():
                    continue
                key = '/'.join(relative).lower()
                if key in seen:
                    raise ValueError('更新包存在重复路径')
                seen.add(key)
                total += item.file_size
                if total > MAX_BYTES:
                    raise ValueError('更新包解压后过大')
                output = destination.joinpath(*relative)
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_bytes(package.read(item))
        for required in ['backend/app.py', 'backend/updater.py', 'scripts/launch.py', 'frontend/dist/index.html', 'requirements.txt']:
            if not (destination / required).is_file():
                raise ValueError('更新包缺少程序文件')
        if (destination / 'requirements.txt').read_bytes() != (root / 'requirements.txt').read_bytes():
            raise ValueError('本次更新需要更换运行依赖，请下载安装包升级')
        if f"VERSION = '{release['version']}'" not in (destination / 'backend/updater.py').read_text('utf-8'):
            raise ValueError('更新版本与程序内容不匹配')
        return destination
    except Exception:
        shutil.rmtree(destination, ignore_errors=True)
        raise


def apply(root, staged):
    """Called only after the owned API process has stopped. Data/.venv are untouched."""
    backup = root / '.updates' / 'backup'
    shutil.rmtree(backup, ignore_errors=True)
    backup.mkdir(parents=True)
    changed = []
    try:
        for name in sorted(MANAGED):
            source = staged / name
            if not source.exists():
                continue
            target = root / name
            if target.exists():
                target.rename(backup / name)
            changed.append(name)
            if source.is_dir():
                shutil.copytree(source, target)
            else:
                shutil.copy2(source, target)
        return backup, changed
    except Exception:
        rollback(root, backup, changed)
        raise


def rollback(root, backup, changed):
    for name in reversed(changed):
        target = root / name
        if target.is_dir():
            shutil.rmtree(target)
        else:
            target.unlink(missing_ok=True)
        old = backup / name
        if old.exists():
            old.rename(target)


def install_routes(app, root, store, lock, active):
    import asyncio
    from fastapi import HTTPException

    def supported():
        return os.name == 'nt' and os.environ.get('ZJ_STUDIO_SUPERVISED') == '1'

    @app.get('/api/updates/status')
    async def status():
        result = root / '.updates' / 'result.json'
        return {'version': VERSION, 'canRestart': supported(),
                'activeJobs': sum(j['status'] in active for j in store.all('job')),
                'lastResult': json.loads(result.read_text('utf-8')) if result.exists() else None}

    async def fetch_release():
        try:
            source = load_source(root)
            if not source:
                return None
            body = await asyncio.to_thread(download_public, source['manifestUrl'] + '?check=' + str(int(time.time())), 64000)
            return validate_release(json.loads(body), source)
        except Exception as exc:
            raise HTTPException(503, '检查更新失败，当前版本 v' + VERSION + '：' + str(exc)) from exc

    @app.get('/api/updates')
    async def check():
        latest = await fetch_release()
        return {'current': VERSION, 'latest': latest['version'] if latest else VERSION,
                'sourceConfigured': latest is not None,
                'available': latest is not None and version(latest['version']) > version(VERSION),
                'canRestart': supported(), 'notes': str(latest.get('notes', ''))[:2000] if latest else '',
                'message': '' if latest else '更新发布源尚未配置，当前程序未更改。'}

    @app.post('/api/updates/install')
    async def install():
        from starlette.datastructures import UploadFile
        if not supported():
            raise HTTPException(409, '请使用桌面快捷方式或 start.bat 启动 Studio 后更新')
        if getattr(app.state, 'downloading_update', False) or getattr(app.state, 'updating', False):
            raise HTTPException(409, '正在更新，请等待重启')
        if any(j['status'] in active for j in store.all('job')):
            raise HTTPException(409, '有未结束任务，请完成或核对任务后再更新')
        app.state.downloading_update = True
        try:
            latest = await fetch_release()
            if latest is None:
                raise HTTPException(409, '更新发布源尚未配置')
            if version(latest['version']) <= version(VERSION):
                raise HTTPException(409, '当前已是最新版本')
            body = await asyncio.to_thread(download_public, latest['url'], latest['size'])
            return await accept_package(latest, UploadFile(io.BytesIO(body), filename='studio.zip'))
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(503, '更新下载失败，当前程序未更改：' + str(exc)) from exc
        finally:
            app.state.downloading_update = False

    async def accept_package(release, upload):
        if not supported():
            raise HTTPException(409, '请使用桌面快捷方式或 start.bat 启动 Studio 后更新')
        async with lock:
            if getattr(app.state, 'updating', False):
                raise HTTPException(409, '正在更新，请等待重启')
            if any(j['status'] in active for j in store.all('job')):
                raise HTTPException(409, '有未结束任务，请完成或核对任务后再更新')
            archive = None
            staged = None
            app.state.updating = True
            try:
                validate_release(release, load_source(root))
                if version(release['version']) <= version(VERSION):
                    raise ValueError('当前已是最新版本')
                updates = root / '.updates'
                updates.mkdir(exist_ok=True)
                archive = updates / 'download.zip.part'
                received = 0
                with archive.open('wb') as output:
                    while chunk := await upload.read(1024 * 1024):
                        received += len(chunk)
                        if received > release['size']:
                            raise ValueError('更新包大小不符')
                        output.write(chunk)
                staged = await asyncio.to_thread(stage, root, archive, release)
                request = updates / 'request.tmp'
                request.write_text(json.dumps({'pid': os.getpid(), 'staged': staged.name, 'version': release['version']}), 'utf-8')
                request.replace(updates / 'request.json')
                return {'restarting': True, 'version': release['version']}
            except Exception as exc:
                app.state.updating = False
                if staged:
                    shutil.rmtree(staged, ignore_errors=True)
                if isinstance(exc, HTTPException):
                    raise
                raise HTTPException(422, '更新未完成，当前版本保留：' + str(exc)) from exc
            finally:
                if archive:
                    archive.unlink(missing_ok=True)
                await upload.close()

    return {'accept': accept_package, 'status': status}
