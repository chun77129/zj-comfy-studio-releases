import copy
import json
import uuid

from test_studio import rig, ROOT, reconcile
from test_bridge import paired
from backend.workflows import preflight


def test_optional_combo_not_required_and_dynamic_fields_preserved():
    graph = {'1': {'class_type': 'TextGenerate', 'inputs': {'sampling_mode': 'on', 'sampling_mode.temperature': 0.7}}}
    info = {'TextGenerate': {'input': {'required': {'sampling_mode': ['COMFY_DYNAMICCOMBO_V3', {}]}, 'optional': {'mtp': [['auto', 'off']]}}}}
    assert preflight(graph, info) == []
    assert graph['1']['inputs']['sampling_mode.temperature'] == 0.7


def test_official_history_prompt_capture_and_native_png_metadata(rig):
    client, fake, app, _ = rig
    headers, _ = paired(client)
    graph = json.loads((ROOT / 'workflows/krea2-official-api.json').read_text())
    graph['30:19']['inputs']['value'] = '中文原始提示词'
    # Both features enabled, representing a full official execution graph.
    graph['30:23']['inputs']['value'] = True
    graph['30:27']['inputs']['string_b'] = 'monochrome ink wash style'
    for n in graph.values():
        fake.info.setdefault(n['class_type'], {'input': {'required': {}}})
    fake.info['LoraLoaderModelOnly']['input']['required']['lora_name'][0].append('krea2_darkbrush.safetensors')
    native = json.loads((ROOT / 'workflows/krea2-official-full.json').read_text())
    r = client.post('/bridge/jobs', headers=headers, json={'id': str(uuid.uuid4()), 'web_job_id': 'official-web', 'graph': graph, 'workflow': native})
    assert r.status_code == 200, r.text
    job = r.json()
    assert fake.posts[0]['extra_data']['extra_pnginfo']['workflow']['definitions'] == native['definitions']
    assert fake.posts[0]['prompt']['30:16']['inputs']['sampling_mode.temperature'] == 0.7
    fake.finish(job['prompt_id'])
    fake.history[job['prompt_id']]['outputs']['30:20'] = {'text': ['Expanded thunderstorm mountain scene.']}
    done = reconcile(client, app, job)
    assert done['prompt_texts']['original'] == '中文原始提示词'
    assert done['prompt_texts']['final'] == 'Expanded thunderstorm mountain scene., monochrome ink wash style'
    assert done['native_workflow']['id'] == native['id']


def test_missing_text_output_is_not_fabricated(rig):
    client, fake, app, _ = rig
    from test_studio import submit
    job = submit(client).json()
    fake.finish(job['prompt_id'])
    done = reconcile(client, app, job)
    assert 'prompt_texts' not in done


def match_info(allowed='*'):
    template = {'template_id': 'switch', 'allowed_types': allowed}
    return {'input': {'required': {'switch': ['BOOLEAN']}, 'optional': {
        'on_true': ['COMFY_MATCHTYPE_V3', {'template': template, 'optional': True}],
        'on_false': ['COMFY_MATCHTYPE_V3', {'template': template, 'optional': True}]}}, 'output': ['COMFY_MATCHTYPE_V3']}


def test_official_v3_switch_accepts_string_and_model_paths_without_false_errors():
    graph = {'text': {'class_type': 'PrimitiveStringMultiline', 'inputs': {'value': '中文'}},
             'switch': {'class_type': 'ComfySwitchNode', 'inputs': {'switch': True, 'on_true': ['text', 0], 'on_false': ['text', 0]}},
             'encode': {'class_type': 'CLIPTextEncode', 'inputs': {'text': ['switch', 0]}}}
    info = {'PrimitiveStringMultiline': {'input': {'required': {'value': ['STRING']}}, 'output': ['STRING']},
            'ComfySwitchNode': match_info(), 'CLIPTextEncode': {'input': {'required': {'text': ['STRING']}}, 'output': ['CONDITIONING']}}
    assert preflight(graph, info) == []
    info['PrimitiveStringMultiline']['output'] = ['MODEL']
    info['CLIPTextEncode']['input']['required']['text'] = ['MODEL']
    assert preflight(graph, info) == []
    info['CLIPTextEncode']['input']['required']['text'] = ['STRING']
    assert any('端口类型不兼容' in e for e in preflight(graph, info))


def test_matchtype_constraints_and_same_group_remain_enforced():
    graph = {'text': {'class_type': 'Text', 'inputs': {}}, 'model': {'class_type': 'Model', 'inputs': {}},
             'switch': {'class_type': 'ComfySwitchNode', 'inputs': {'switch': True, 'on_true': ['text', 0], 'on_false': ['model', 0]}}}
    info = {'Text': {'output': ['STRING']}, 'Model': {'output': ['MODEL']}, 'ComfySwitchNode': match_info()}
    assert any('匹配类型不一致' in e for e in preflight(graph, info))
    graph['switch']['inputs']['on_false'] = ['text', 0]
    info['ComfySwitchNode'] = match_info('IMAGE')
    assert any('端口类型不兼容' in e for e in preflight(graph, info))


def test_union_port_type_and_unknown_generic_are_not_concrete_mismatches():
    graph = {'a': {'class_type': 'Source', 'inputs': {}}, 'b': {'class_type': 'Target', 'inputs': {'value': ['a', 0]}}}
    info = {'Source': {'output': ['STRING']}, 'Target': {'input': {'required': {'value': ['STRING,INT']}}}}
    assert preflight(graph, info) == []
    info['Source']['output'] = ['MODEL']
    assert any('端口类型不兼容' in e for e in preflight(graph, info))


def test_full_official_graph_with_v3_polymorphic_node_definitions():
    graph = json.loads((ROOT / 'workflows/krea2-official-api.json').read_text())
    outputs = {'CLIPTextEncode': ['CONDITIONING'], 'EmptyLatentImage': ['LATENT'], 'KSampler': ['LATENT'],
               'VAEDecode': ['IMAGE'], 'UNETLoader': ['MODEL'], 'CLIPLoader': ['CLIP'], 'VAELoader': ['VAE'],
               'ConditioningZeroOut': ['CONDITIONING'], 'LoraLoaderModelOnly': ['MODEL'],
               'TextGenerate': ['STRING'], 'StringConcatenate': ['STRING'], 'PrimitiveStringMultiline': ['STRING'],
               'PreviewAny': ['*'], 'PrimitiveBoolean': ['BOOLEAN'], 'ResolutionSelector': ['INT', 'INT'], 'SaveImage': []}
    info = {kind: {'input': {'required': {}}, 'output': types} for kind, types in outputs.items()}
    info['ComfySwitchNode'] = match_info()
    info['CLIPTextEncode']['input']['required'] = {'text': ['STRING'], 'clip': ['CLIP']}
    info['KSampler']['input']['required'] = {'model': ['MODEL'], 'positive': ['CONDITIONING'], 'negative': ['CONDITIONING'], 'latent_image': ['LATENT']}
    info['StringConcatenate']['input']['required'] = {'string_a': ['STRING'], 'string_b': ['STRING']}
    info['PreviewAny']['input']['required'] = {'source': ['*']}
    assert preflight(graph, info) == []
    graph['30:21']['inputs']['on_true'] = ['30:10', 0]
    assert any('匹配类型不一致' in e for e in preflight(graph, info))
