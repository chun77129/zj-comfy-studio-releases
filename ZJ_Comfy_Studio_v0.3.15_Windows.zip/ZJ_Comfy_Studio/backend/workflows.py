"""API-format workflows, immutable snapshots, explicit editable scalar inputs."""
import copy
import hashlib
import json
from fastapi import HTTPException


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def normalize(raw):
    if not isinstance(raw, dict):
        raise HTTPException(422, '工作流必须是 JSON 对象')
    if 'nodes' in raw or 'definitions' in raw:
        raise HTTPException(422, '画布需要通过工作流导入入口连接 ComfyUI 转换，请先连接 ComfyUI 后导入。')
    graph = raw.get('prompt', raw)
    if not isinstance(graph, dict) or not graph or len(graph) > 1000:
        raise HTTPException(422, '无效或过大的 API 工作流')
    for key, node in graph.items():
        if not isinstance(node, dict) or not isinstance(node.get('class_type'), str) or not isinstance(node.get('inputs'), dict):
            raise HTTPException(422, f'节点 {key} 缺少 class_type / inputs，请使用 API 格式')
        for value in node['inputs'].values():
            if isinstance(value, list) and (len(value) != 2 or str(value[0]) not in graph or not isinstance(value[1], int)):
                raise HTTPException(422, f'节点 {key} 存在无效连接')
    return copy.deepcopy(graph)


def canvas_prompt(raw, info):
    """Compile reachable canvas nodes using the connected server's widget schema."""
    nodes = raw.get('nodes')
    if not isinstance(nodes, list) or not nodes or len(nodes) > 1000:
        raise HTTPException(422, '画布节点为空或超过 1000 个')
    by_id = {str(n['id']): n for n in nodes}
    if len(by_id) != len(nodes):
        raise HTTPException(422, '画布包含重复节点 ID')
    edges = {}
    for link in raw.get('links', []):
        if isinstance(link, list):
            lid, src, slot, dst, target, *_ = link
        else:
            lid, src, slot, dst, target = (link[k] for k in ('id', 'origin_id', 'origin_slot', 'target_id', 'target_slot'))
        edges[str(lid)] = (str(src), slot, str(dst), target)
    roots = [str(n['id']) for n in nodes if info.get(n['type'], {}).get('output_node') or n['type'] in {'SaveImage', 'PreviewImage'}]
    if not roots:
        raise HTTPException(422, '画布没有可执行输出节点，请添加 SaveImage 等输出节点')
    graph, visiting = {}, set()
    subgraphs = {s['id'] for s in raw.get('definitions', {}).get('subgraphs', [])}

    def visit(nid):
        if nid in graph:
            return
        if nid in visiting:
            raise HTTPException(422, f'画布存在循环连接：节点 {nid}')
        node = by_id.get(nid)
        if not node:
            raise HTTPException(422, f'连接来源节点不存在：{nid}')
        kind = node['type']
        if kind in subgraphs:
            raise HTTPException(422, f'节点 {nid}（{kind}）是子图，当前 Studio 尚不能展开；请在 ComfyUI 导出 API JSON')
        if node.get('mode', 0) != 0:
            raise HTTPException(422, f'节点 {nid}（{kind}）已禁用或旁路，请先在 ComfyUI 恢复普通模式')
        spec = info.get(kind)
        if not spec:
            raise HTTPException(422, f'缺少节点：{kind}（{nid}），请在当前 ComfyUI 安装对应节点后重试')
        visiting.add(nid)
        inputs = {}
        serialized = node.get('inputs', [])
        for index, pin in enumerate(serialized):
            lid = pin.get('link')
            if lid is None:
                continue
            edge = edges.get(str(lid))
            if not edge or edge[2:] != (nid, index):
                raise HTTPException(422, f'节点 {nid}.{pin["name"]} 的画布连线无效')
            visit(edge[0])
            inputs[pin['name']] = [edge[0], edge[1]]
        vals = node.get('widgets_values', [])
        if not isinstance(vals, list):
            raise HTTPException(422, f'节点 {nid}（{kind}）的控件格式不受支持，请导出 API JSON')
        cursor = 0
        for group in ('required', 'optional'):
            rules = spec.get('input', {}).get(group, {})
            order = spec.get('input_order', {}).get(group, list(rules))
            for name in order:
                rule = rules[name]
                typ = rule[0]
                options = rule[1] if len(rule) > 1 and isinstance(rule[1], dict) else {}
                pin = next((p for p in serialized if p['name'] == name), None)
                widget = isinstance(typ, list) or typ in ('STRING', 'INT', 'FLOAT', 'BOOLEAN', 'COMBO')
                if not widget or options.get('forceInput') or (pin is not None and not pin.get('widget')):
                    continue
                if cursor >= len(vals):
                    if name in inputs or group == 'optional':
                        continue
                    raise HTTPException(422, f'节点 {nid}（{kind}）缺少控件值：{name}')
                value = vals[cursor]
                cursor += 1
                if name not in inputs:
                    inputs[name] = value
                # ComfyUI stores the seed UI control, which is not a server input.
                if (options.get('control_after_generate') or name in ('seed', 'noise_seed')) and cursor < len(vals) and vals[cursor] in ('fixed', 'increment', 'decrement', 'randomize'):
                    cursor += 1
        if cursor != len(vals):
            raise HTTPException(422, f'节点 {nid}（{kind}）控件无法与本机定义对应（{cursor}/{len(vals)}），请导出 API JSON')
        graph[nid] = {'class_type': kind, 'inputs': inputs, '_meta': {'title': node.get('title', kind)}}
        visiting.remove(nid)

    for nid in roots:
        visit(nid)
    errors = preflight(graph, info)
    if errors:
        raise HTTPException(422, '；'.join(errors))
    return normalize(graph)


def fields(graph):
    result = []
    for nid, node in graph.items():
        title = node.get('_meta', {}).get('title', node['class_type'])
        for key, value in node['inputs'].items():
            if isinstance(value, (str, int, float, bool)):
                result.append(dict(id=f'{nid}.{key}', node=nid, input=key, title=title,
                                   class_type=node['class_type'], value=value))
    return result


def apply_values(graph, values):
    graph = copy.deepcopy(graph)
    editable = {f['id']: f for f in fields(graph)}
    for key, value in values.items():
        f = editable.get(key)
        if f is None:
            raise HTTPException(422, f'参数不存在或是连线：{key}')
        old = f['value']
        if isinstance(old, bool):
            valid = isinstance(value, bool)
        elif isinstance(old, int):
            valid = isinstance(value, int) and not isinstance(value, bool)
        elif isinstance(old, float):
            valid = isinstance(value, (int, float)) and not isinstance(value, bool)
        else:
            valid = isinstance(value, str)
        if not valid:
            raise HTTPException(422, f'参数类型不符：{key}')
        graph[f['node']]['inputs'][f['input']] = value
    return graph


def add_loras(graph, loras, target):
    if not loras:
        return graph
    if not target or '.' not in target:
        raise HTTPException(422, '请先指定 LoRA 的模型输入位置')
    nid, key = target.split('.', 1)
    link = graph.get(nid, {}).get('inputs', {}).get(key)
    if key != 'model' or not isinstance(link, list):
        raise HTTPException(422, 'LoRA 目标必须是 model 连线输入')
    graph = copy.deepcopy(graph)
    for index, lora in enumerate(loras):
        lid = f'zj_lora_{index}'
        while lid in graph:
            lid += '_'
        graph[lid] = {'class_type': 'LoraLoaderModelOnly', 'inputs': {
            'model': link, 'lora_name': lora['name'], 'strength_model': lora['strength']}}
        link = [lid, 0]
    graph[nid]['inputs'][key] = link
    return graph


MODEL_INPUTS = {
    'ckpt_name': ('Checkpoint', 'models/checkpoints'),
    'unet_name': ('扩散模型', 'models/diffusion_models'),
    'clip_name': ('文本编码器', 'models/text_encoders'),
    'clip_name1': ('文本编码器', 'models/text_encoders'),
    'clip_name2': ('文本编码器', 'models/text_encoders'),
    'vae_name': ('VAE', 'models/vae'),
    'lora_name': ('LoRA', 'models/loras'),
    'control_net_name': ('ControlNet', 'models/controlnet'),
    'upscale_model_name': ('放大模型', 'models/upscale_models'),
    'style_model_name': ('风格模型', 'models/style_models'),
    'gligen_name': ('GLIGEN 模型', 'models/gligen'),
}


def model_location(kind, key):
    overrides = {('CLIPVisionLoader', 'clip_name'): ('视觉编码器', 'models/clip_vision'),
                 ('UpscaleModelLoader', 'model_name'): ('放大模型', 'models/upscale_models')}
    return overrides.get((kind, key), MODEL_INPUTS.get(key))


MATCH_TYPE = 'COMFY_MATCHTYPE_V3'


def type_tokens(value):
    return {s.strip() for s in value.split(',')} if isinstance(value, str) else set()


def types_compatible(expected, actual):
    a, b = type_tokens(expected), type_tokens(actual)
    # MatchType is a schema placeholder, never a concrete runtime type.
    return not a or not b or bool((a | b) & {'*', 'ANY', MATCH_TYPE}) or bool(a & b)


def matchtype_groups(node, spec):
    groups = {}
    inputs = spec.get('input', {})
    for key, rule in {**inputs.get('required', {}), **inputs.get('optional', {})}.items():
        if isinstance(rule, list) and rule and rule[0] == MATCH_TYPE:
            template = rule[1].get('template', {}) if len(rule) > 1 and isinstance(rule[1], dict) else {}
            identity = template.get('template_id')
            if identity:
                groups.setdefault(identity, []).append((key, template))
    return groups


def resolved_output(graph, info, nid, slot, visiting=None):
    visiting = set(visiting or ())
    if (nid, slot) in visiting:
        return MATCH_TYPE
    visiting.add((nid, slot))
    node = graph.get(nid, {})
    spec = info.get(node.get('class_type'), {})
    outputs = spec.get('output', [])
    if not isinstance(slot, int) or isinstance(slot, bool) or slot < 0 or slot >= len(outputs):
        return None
    actual = outputs[slot]
    if actual != MATCH_TYPE:
        return actual
    groups = matchtype_groups(node, spec)
    # A single template group can determine the generic output. Multiple groups
    # need explicit output-template metadata, so leave those to ComfyUI.
    if len(groups) != 1:
        return MATCH_TYPE
    types = set()
    for key, _ in next(iter(groups.values())):
        value = node.get('inputs', {}).get(key)
        if isinstance(value, list) and len(value) == 2:
            resolved = resolved_output(graph, info, str(value[0]), value[1], visiting)
            types.update(type_tokens(resolved) - {'*', 'ANY', MATCH_TYPE})
    return ','.join(sorted(types)) if types else MATCH_TYPE


def preflight_report(graph, info):
    """Compare the frozen recipe with the connected server, without loading models."""
    from difflib import get_close_matches
    import time
    issues, seen = [], {}

    def add(kind, message, nid, key=None, severity='error', identity=None, **details):
        dedup = identity or (kind, str(nid), key)
        use = {'nodeId': str(nid), 'input': key}
        if dedup in seen:
            if use not in seen[dedup]['uses']:
                seen[dedup]['uses'].append(use)
            return
        item = {'kind': kind, 'severity': severity, 'message': message, 'uses': [use], **details}
        seen[dedup] = item
        issues.append(item)

    for nid, node in graph.items():
        kind = node['class_type']
        spec = info.get(kind)
        if not spec:
            add('missing_node', f'缺少节点：{kind}', nid, identity=('missing_node', kind),
                nodeType=kind, action='在 ComfyUI-Manager 按节点名称查找对应扩展；也可能是扩展加载失败或 ComfyUI 版本不兼容。修复后重启 ComfyUI 并重新检测。')
            for key, value in node['inputs'].items():
                if model_location(kind, key) and isinstance(value, str):
                    label, directory = model_location(kind, key)
                    add('unverified_model', f'节点未加载，暂时无法检查模型：{value}', nid, key, 'warning',
                        filename=value, modelType=label, directory=directory)
            continue
        if spec.get('api_node') or kind.lower().startswith(('openai', 'gemini')):
            add('blocked_api', f'不执行可能依赖付费 API 的节点：{kind}', nid)
        inputs = spec.get('input', {})
        required = inputs.get('required', {})
        for key, rule in {**required, **inputs.get('optional', {})}.items():
            value = node['inputs'].get(key)
            if key not in node['inputs'] or value is None:
                if key in required:
                    add('missing_input', f'缺少输入：{nid}.{key}', nid, key)
                continue
            if isinstance(value, list):
                if len(value) != 2:
                    add('invalid_connection', f'来源输出端口无效：{nid}.{key}', nid, key)
                    continue
                source_id, output_index = str(value[0]), value[1]
                source = graph.get(source_id)
                if not source:
                    add('invalid_connection', f'来源节点不存在：{nid}.{key} <- {source_id}', nid, key)
                    continue
                source_spec = info.get(source['class_type'])
                if not source_spec:
                    add('unchecked_connection', f'上游节点 {source_id} 未加载，修复后再检查 {nid}.{key}', nid, key,
                        'warning', sourceNode=source_id)
                    continue
                if 'output' not in source_spec:
                    add('unchecked_connection', f'节点 {source_id} 未提供输出定义，无法检查 {nid}.{key}', nid, key, 'warning')
                    continue
                outputs = source_spec['output']
                if not isinstance(output_index, int) or isinstance(output_index, bool) or output_index < 0 or output_index >= len(outputs):
                    add('invalid_connection', f'来源输出端口无效：{nid}.{key} <- {source_id}[{output_index}]', nid, key)
                    continue
                expected = rule[0] if isinstance(rule, list) and rule else None
                actual = resolved_output(graph, info, source_id, output_index)
                if expected == MATCH_TYPE:
                    template = rule[1].get('template', {}) if len(rule) > 1 and isinstance(rule[1], dict) else {}
                    expected = template.get('allowed_types', '*')
                if not types_compatible(expected, actual):
                    add('incompatible_connection', f'端口类型不兼容：{nid}.{key} 需要 {expected}，来源为 {actual}', nid, key)
                continue
            options = rule[0] if isinstance(rule, list) and rule and isinstance(rule[0], list) else None
            model = model_location(kind, key)
            if model and isinstance(value, str):
                label, directory = model
                if options is None:
                    add('unverified_model', f'节点未提供模型清单，暂时无法检查：{value}', nid, key, 'warning', filename=value, modelType=label, directory=directory)
                elif value not in options:
                    choices = [v for v in options if isinstance(v, str)]
                    # Same basename in another folder is especially useful; never substitute it automatically.
                    base = value.replace('\\', '/').rsplit('/', 1)[-1].lower()
                    matching = [v for v in choices if v.replace('\\', '/').rsplit('/', 1)[-1].lower() == base]
                    suggestions = list(dict.fromkeys(matching + get_close_matches(value, choices, n=5, cutoff=.35)))[:5]
                    add('unavailable_model', f'ComfyUI 未识别所选{label}：{value}', nid, key,
                        identity=('unavailable_model', directory, value), filename=value, modelType=label,
                        directory=directory, alternatives=suggestions, availableCount=len(choices),
                        action='确认对应模型已安装并由当前 ComfyUI 识别；如在子目录中，选择其实际相对文件名。修改模型路径配置或新增模型后刷新／重启 ComfyUI，再重新检测。候选名称仅供核对，不保证兼容。')
                continue
            if options is not None and value not in options:
                add('invalid_option', f'参数选项不存在：{nid}.{key} = {value}', nid, key,
                    value=value, alternatives=options[:20])
            elif isinstance(rule, list) and rule and rule[0] in ('INT', 'FLOAT', 'BOOLEAN', 'STRING'):
                typ = rule[0]
                valid = (isinstance(value, int) and not isinstance(value, bool)) if typ == 'INT' else (isinstance(value, (float, int)) and not isinstance(value, bool)) if typ == 'FLOAT' else isinstance(value, bool) if typ == 'BOOLEAN' else isinstance(value, str)
                if not valid:
                    add('invalid_value', f'参数类型不符：{nid}.{key} 需要 {typ}', nid, key)
    # Inputs sharing one MatchType template must agree on the concrete type.
    for nid, node in graph.items():
        for identity, pins in matchtype_groups(node, info.get(node['class_type'], {})).items():
            bound = None
            for key, template in pins:
                value = node['inputs'].get(key)
                if not isinstance(value, list) or len(value) != 2:
                    continue
                actual = resolved_output(graph, info, str(value[0]), value[1])
                if not actual or type_tokens(actual) & {'*', 'ANY', MATCH_TYPE}:
                    continue
                if bound and not types_compatible(bound, actual):
                    add('incompatible_connection', f'匹配类型不一致：节点 {nid} 的 {identity} 组同时连接 {bound} 与 {actual}', nid, key)
                else:
                    bound = actual
    errors = [i['message'] for i in issues if i['severity'] == 'error']
    warnings = [i['message'] for i in issues if i['severity'] == 'warning']
    counts = {key: sum(i['kind'] == key for i in issues) for key in ('missing_node', 'unavailable_model', 'unverified_model', 'invalid_option', 'invalid_connection', 'incompatible_connection', 'missing_input', 'invalid_value', 'blocked_api', 'unchecked_connection')}
    return {'valid': not errors and not warnings, 'errors': errors, 'warnings': warnings, 'issues': issues,
            'summary': counts, 'checkedAt': time.time(), 'basis': '当前连接的 ComfyUI /object_info；不加载模型、不提交生成任务，不代表硬盘扫描或显存兼容测试。'}


def preflight(graph, info):
    report = preflight_report(graph, info)
    # Unknown output declarations are warnings; actual ComfyUI validates at submission.
    return report['errors']
