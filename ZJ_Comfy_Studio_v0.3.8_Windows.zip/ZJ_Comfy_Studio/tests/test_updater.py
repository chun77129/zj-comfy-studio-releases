import hashlib
from pathlib import Path
import zipfile
import pytest
from backend import updater
from test_studio import rig


def release(tmp_path, extra=None, requirements=b'httpx==1'):
    root = tmp_path / 'installed'
    root.mkdir(exist_ok=True)
    (root / 'requirements.txt').write_bytes(b'httpx==1')
    (root / 'backend').mkdir(exist_ok=True)
    (root / 'backend/app.py').write_text('OLD')
    (root / 'data').mkdir(exist_ok=True)
    (root / 'data/records').write_text('KEEP')
    (root / '.venv').mkdir(exist_ok=True)
    (root / '.venv/interpreter').write_text('KEEP')
    files={'backend/app.py':b'NEW','backend/updater.py':b"VERSION = '0.3.9'",'scripts/launch.py':b'launcher',
           'frontend/dist/index.html':b'NEW HTML','requirements.txt':requirements, **(extra or {})}
    archive=tmp_path/'release.zip'
    with zipfile.ZipFile(archive,'w') as z:
        for name, data in files.items():z.writestr('ZJ_Comfy_Studio/'+name,data)
    manifest={'version':'0.3.9','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
              'size':archive.stat().st_size,'url':updater.SITE+'/downloads/ZJ_Comfy_Studio_v0.3.9_Windows.zip'}
    return root,archive,manifest


def test_update_preserves_data_and_rolls_back(tmp_path):
    root,archive,manifest=release(tmp_path)
    staged=updater.stage(root,archive,manifest)
    assert (root/'backend/app.py').read_text()=='OLD'
    backup,changed=updater.apply(root,staged)
    assert (root/'backend/app.py').read_text()=='NEW'
    assert (root/'data/records').read_text()=='KEEP'
    assert (root/'.venv/interpreter').read_text()=='KEEP'
    updater.rollback(root,backup,changed)
    assert (root/'backend/app.py').read_text()=='OLD'
    assert not (root/'frontend').exists()
    assert (root/'data/records').read_text()=='KEEP'


@pytest.mark.parametrize('extra',[{'../escape':b'x'},{'data/records':b'x'},{'/absolute':b'x'},{'backend/../../escape':b'x'}])
def test_rejects_unsafe_archive_paths(tmp_path,extra):
    root,archive,manifest=release(tmp_path,extra)
    with pytest.raises(ValueError):updater.stage(root,archive,manifest)
    assert (root/'backend/app.py').read_text()=='OLD'
    assert not list((root/'.updates').glob('staged-*'))


def test_rejects_corruption_origin_dependency_change(tmp_path):
    root,archive,manifest=release(tmp_path)
    manifest['sha256']='0'*64
    with pytest.raises(ValueError,match='校验失败'):updater.stage(root,archive,manifest)
    manifest['url']='https://evil.example/payload.zip'
    with pytest.raises(ValueError,match='来源'):updater.validate_release(manifest)
    root,archive,manifest=release(tmp_path,requirements=b'changed dependency')
    with pytest.raises(ValueError,match='运行依赖'):updater.stage(root,archive,manifest)


def test_local_update_endpoints_reject_cross_origin(rig):
    client,_,_,_=rig
    assert client.get('/api/updates/status').json()['version']==updater.VERSION
    assert client.post('/api/updates/install',headers={'origin':updater.SITE}).status_code==403
    assert client.post('/api/updates/install').status_code==409


def test_failed_copy_restores_program(tmp_path,monkeypatch):
    root,archive,manifest=release(tmp_path)
    staged=updater.stage(root,archive,manifest)
    original=updater.shutil.copytree
    def fail(src,dst,*args,**kwargs):
        if Path(src).name=='frontend':raise OSError('disk failure')
        return original(src,dst,*args,**kwargs)
    monkeypatch.setattr(updater.shutil,'copytree',fail)
    with pytest.raises(OSError):updater.apply(root,staged)
    assert (root/'backend/app.py').read_text()=='OLD'
    assert (root/'data/records').read_text()=='KEEP'


def test_browser_supplies_release_without_outbound_requests(tmp_path,monkeypatch):
    import asyncio
    import json
    import httpx
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from types import SimpleNamespace
    from backend.store import Store
    from backend.bridge import install_bridge, SITE
    root,archive,manifest=release(tmp_path)
    def no_network(**kwargs):raise AssertionError('Updater must not download over Python HTTP')
    monkeypatch.setattr(httpx,'AsyncClient',no_network)
    monkeypatch.setattr(updater,'os',SimpleNamespace(name='nt',environ={'ZJ_STUDIO_SUPERVISED':'1'},getpid=lambda:12345))
    app=FastAPI()
    store=Store(tmp_path/'db')
    handlers=updater.install_routes(app,root,store,asyncio.Lock(),{'running'})
    install_bridge(app,store,None,None,None,None,None,handlers)
    payload={'release':json.dumps(manifest)}
    def upload(client,headers):
        return client.post('/bridge/updates/install',headers=headers,data=payload,files={'archive':('studio.zip',archive.read_bytes(),'application/zip')})
    with TestClient(app) as client:
        info=client.get('/api/updates')
        assert info.json()['sourceConfigured'] is False
        assert info.json()['current']==updater.VERSION
        assert upload(client,{'origin':SITE}).status_code==401
        assert upload(client,{'origin':'https://evil.example'}).status_code==403
        code=client.post('/api/pairing/code').json()['code']
        pair=client.post('/bridge/pair',headers={'origin':SITE},json={'code':code}).json()
        headers={'origin':SITE,'authorization':'Bearer '+pair['token']}
        assert client.get('/bridge/health',headers={'origin':SITE}).json()['browserUpdates']
        store.put('job','active',{'id':'active','status':'running'})
        assert upload(client,headers).status_code==409
        assert not (root/'.updates/request.json').exists()
        store.delete('job','active')
        corrupt=client.post('/bridge/updates/install',headers=headers,data=payload,files={'archive':('studio.zip',b'bad','application/zip')})
        assert corrupt.status_code==422
        assert not getattr(app.state,'updating',False)
        result=upload(client,headers)
        assert result.status_code==200,result.text
        assert result.json()['restarting']
        assert upload(client,headers).status_code==409
    pending=json.loads((root/'.updates/request.json').read_text())
    assert pending['pid']==12345
    assert (root/'.updates'/pending['staged']/'backend/app.py').read_text()=='NEW'
    assert (root/'backend/app.py').read_text()=='OLD'
    store.db.close()


def test_browser_status_requires_pairing(rig):
    client,_,_,_=rig
    site=updater.SITE
    assert client.get('/bridge/updates/status',headers={'origin':site}).status_code==401
    assert client.get('/api/updates/status').json()['version']==updater.VERSION
    assert client.post('/api/updates/install').status_code==409


def test_native_update_downloads_and_stages_without_browser(tmp_path,monkeypatch):
    import asyncio,json
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from backend.store import Store
    from types import SimpleNamespace
    root,archive,manifest=release(tmp_path)
    base='https://raw.githubusercontent.com/example/studio-releases/main/windows'
    source={'manifestUrl':base+'/studio-release.json','packageBase':base}
    (root/'update-source.json').write_text(json.dumps(source))
    manifest['url']=base+'/ZJ_Comfy_Studio_v0.3.9_Windows.zip'
    requested=[]
    def download(url,limit):
        requested.append(url)
        return json.dumps(manifest).encode() if url.split('?')[0]==source['manifestUrl'] else archive.read_bytes()
    monkeypatch.setattr(updater,'download_public',download)
    monkeypatch.setattr(updater,'os',SimpleNamespace(name='nt',environ={'ZJ_STUDIO_SUPERVISED':'1'},getpid=lambda:123))
    store=Store(tmp_path/'db');app=FastAPI()
    updater.install_routes(app,root,store,asyncio.Lock(),{'running'})
    with TestClient(app) as client:
        info=client.get('/api/updates').json()
        assert info['current']==updater.VERSION and info['latest']=='0.3.9'
        assert info['available'] and info['sourceConfigured']
        result=client.post('/api/updates/install')
        assert result.status_code==200,result.text
        assert result.json()['restarting']
    assert [url.split('?')[0] for url in requested]==[source['manifestUrl'],source['manifestUrl'],manifest['url']]
    assert (root/'.updates/request.json').exists()
    assert (root/'backend/app.py').read_text()=='OLD'
    store.db.close()


def test_unconfigured_native_update_is_explicit_and_makes_no_request(tmp_path,monkeypatch):
    import asyncio
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from types import SimpleNamespace
    def forbidden(*args):raise AssertionError('No configured release source')
    monkeypatch.setattr(updater,'download_public',forbidden)
    monkeypatch.setattr(updater,'os',SimpleNamespace(name='nt',environ={'ZJ_STUDIO_SUPERVISED':'1'}))
    app=FastAPI();updater.install_routes(app,tmp_path,SimpleNamespace(all=lambda _:[]),asyncio.Lock(),set())
    with TestClient(app) as client:
        info=client.get('/api/updates').json()
        assert not info['sourceConfigured'] and not info['available']
        assert '未配置' in info['message']
        assert client.post('/api/updates/install').status_code==409
    assert not (tmp_path/'.updates').exists()


def test_native_download_failure_keeps_current_program(tmp_path,monkeypatch):
    import asyncio,json
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from types import SimpleNamespace
    root,archive,manifest=release(tmp_path)
    base='https://raw.githubusercontent.com/example/studio-releases/main/windows'
    (root/'update-source.json').write_text(json.dumps({'manifestUrl':base+'/studio-release.json','packageBase':base}))
    def forbidden(*args):raise OSError('403 Forbidden')
    monkeypatch.setattr(updater,'download_public',forbidden)
    monkeypatch.setattr(updater,'os',SimpleNamespace(name='nt',environ={'ZJ_STUDIO_SUPERVISED':'1'}))
    app=FastAPI();updater.install_routes(app,root,SimpleNamespace(all=lambda _:[]),asyncio.Lock(),set())
    with TestClient(app) as client:
        assert client.post('/api/updates/install').status_code==503
    assert not app.state.downloading_update
    assert (root/'backend/app.py').read_text()=='OLD'
    assert not (root/'.updates/request.json').exists()
