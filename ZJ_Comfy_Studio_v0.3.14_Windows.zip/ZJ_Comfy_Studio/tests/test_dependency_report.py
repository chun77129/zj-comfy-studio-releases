import json
from pathlib import Path
from backend.workflows import preflight_report


def spec(required, outputs=()):
    return {'input': {'required': required}, 'output': list(outputs)}


def test_mj_screenshot_separates_two_nodes_seven_models_and_cascade():
    nodes = json.loads((Path(__file__).parent / 'fixtures/mj-canvas.json').read_text())['nodes']
    loras = [n for n in nodes if n['type'] == 'LoraLoaderModelOnly']
    graph = {str(n['id']): {'class_type': n['type'], 'inputs': {'lora_name': n['widgets_values'][0]}} for n in loras}
    graph.update({
        '214': {'class_type': 'CR Prompt Text', 'inputs': {'prompt': 'test'}},
        '199': {'class_type': 'CLIPTextEncode', 'inputs': {'text': ['214', 0]}},
        '216': {'class_type': 'ConditioningKrea2Rebalance', 'inputs': {}},
        '202': {'class_type': 'KSampler', 'inputs': {'positive': ['216', 0]}},
        '215': {'class_type': 'UNETLoader', 'inputs': {'unet_name': 'krea-2-turbo.safetensors'}},
    })
    info = {'LoraLoaderModelOnly': spec({'lora_name': [[]]}, ['MODEL']),
            'UNETLoader': spec({'unet_name': [['installed.safetensors']]}, ['MODEL']),
            'CLIPTextEncode': spec({'text': ['STRING']}, ['CONDITIONING']),
            'KSampler': spec({'positive': ['CONDITIONING']}, ['LATENT'])}
    report = preflight_report(graph, info)
    assert report['summary']['missing_node'] == 2
    assert report['summary']['unavailable_model'] == 7
    assert report['summary']['unchecked_connection'] == 2
    assert report['summary']['invalid_connection'] == 0
    assert len(report['errors']) == 9
    assert not report['valid']
    models = [i for i in report['issues'] if i['kind'] == 'unavailable_model']
    assert sum(m['directory'] == 'models/loras' for m in models) == 6
    assert sum(m['directory'] == 'models/diffusion_models' for m in models) == 1


def test_same_model_is_grouped_and_subfolder_name_is_suggestion_only():
    graph = {str(i): {'class_type': 'LoraLoaderModelOnly', 'inputs': {'lora_name': 'cat.safetensors'}} for i in (1, 2)}
    report = preflight_report(graph, {'LoraLoaderModelOnly': spec({'lora_name': [['folder/cat.safetensors']]}, ['MODEL'])})
    assert report['summary']['unavailable_model'] == 1
    issue = report['issues'][0]
    assert issue['alternatives'] == ['folder/cat.safetensors']
    assert len(issue['uses']) == 2
    assert graph['1']['inputs']['lora_name'] == 'cat.safetensors'
    graph['1']['inputs']['lora_name'] = graph['2']['inputs']['lora_name'] = 'folder/cat.safetensors'
    assert preflight_report(graph, {'LoraLoaderModelOnly': spec({'lora_name': [['folder/cat.safetensors']]})})['valid']


def test_enum_option_is_not_a_model_and_true_bad_port_still_fails():
    graph = {'1': {'class_type': 'Source', 'inputs': {}}, '2': {'class_type': 'Consumer', 'inputs': {'image': ['1', 2], 'sampler': 'bad', 'steps': 'eight'}}}
    info = {'Source': spec({}, ['IMAGE']), 'Consumer': spec({'image': ['IMAGE'], 'sampler': [['euler']], 'steps': ['INT']})}
    report = preflight_report(graph, info)
    assert report['summary']['invalid_option'] == 1
    assert report['summary']['invalid_connection'] == 1
    assert report['summary']['invalid_value'] == 1
    assert report['summary']['unavailable_model'] == 0


def test_unavailable_inventory_is_unverified_not_missing():
    graph = {'1': {'class_type': 'CustomLoader', 'inputs': {'unet_name': 'unknown.safetensors'}}}
    report = preflight_report(graph, {'CustomLoader': spec({'unet_name': ['STRING']})})
    assert report['summary']['unverified_model'] == 1
    assert report['summary']['unavailable_model'] == 0
    assert not report['valid']


def test_loader_specific_model_folders():
    graph = {'1': {'class_type': 'CLIPVisionLoader', 'inputs': {'clip_name': 'vision.safetensors'}},
             '2': {'class_type': 'UpscaleModelLoader', 'inputs': {'model_name': '4x.pth'}}}
    report = preflight_report(graph, {'CLIPVisionLoader': spec({'clip_name': [[]]}), 'UpscaleModelLoader': spec({'model_name': [[]]})})
    assert {i['directory'] for i in report['issues']} == {'models/clip_vision', 'models/upscale_models'}
