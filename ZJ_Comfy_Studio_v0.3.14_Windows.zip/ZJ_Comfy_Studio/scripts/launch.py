"""Supervise the local API and open only this app after its health check succeeds."""
import json
import os
import secrets
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent.parent
URL = 'http://127.0.0.1:8765'
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def entry_url(state, standalone=False):
    if standalone:
        return URL
    return None if state.get('paired') else URL + '/connect'


def open_entry():
    try:
        with opener.open(URL + '/api/health', timeout=2) as response:
            target = entry_url(json.load(response), '--standalone' in sys.argv)
        if target:
            webbrowser.open(target)
    except Exception:
        print('Studio is ready. Continue in the website; pairing help: ' + URL + '/connect')


def ours():
    try:
        with opener.open(URL + '/api/health', timeout=1) as response:
            return json.load(response).get('service') == 'zj-comfy-studio'
    except Exception:
        return False



def owns_update(request, process):
    """Windows venv redirectors may have a different PID than the API child."""
    expected = getattr(process, 'studio_instance', '')
    actual = request.get('instanceId', '')
    return bool(expected and isinstance(actual, str) and secrets.compare_digest(expected, actual))


def valid_staging(root, name):
    if not isinstance(name, str) or Path(name).name != name or not name.startswith('staged-'):
        return None
    folder = root / '.updates'
    staged = folder / name
    if staged.is_symlink() or not staged.is_dir() or staged.resolve().parent != folder.resolve():
        return None
    return staged


def main():
    if not (ROOT / 'frontend/dist/index.html').is_file():
        print('Frontend build missing. In frontend, run npm install and npm run build.')
        return 1
    if ours():
        open_entry()
        print('Studio is already running at ' + URL)
        return 0
    with socket.socket() as sock:
        try:
            sock.bind(('127.0.0.1', 8765))
        except OSError:
            print('Port 8765 is occupied by another program. Close it and retry.')
            return 1
    sys.path.insert(0, str(ROOT))
    from backend.updater import apply, rollback
    from backend.update_progress import write_progress
    options = {'creationflags': subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == 'nt' else {}
    def spawn():
        instance_id = secrets.token_hex(16)
        process = subprocess.Popen([sys.executable, '-m', 'uvicorn', 'backend.app:app', '--host', '127.0.0.1', '--port', '8765'], cwd=ROOT,
            env={**os.environ, 'ZJ_STUDIO_SUPERVISED': '1', 'ZJ_STUDIO_INSTANCE': instance_id}, **options)
        process.studio_instance = instance_id
        return process
    def stop(process):
        if process.poll() is not None:
            return
        try:
            process.send_signal(signal.CTRL_BREAK_EVENT if os.name == 'nt' else signal.SIGINT)
            process.wait(timeout=15)
        except (OSError, subprocess.TimeoutExpired, KeyboardInterrupt):
            process.terminate()
            process.wait(timeout=10)
    def ready(process, expected=None):
        for _ in range(120):
            if process.poll() is not None:
                return False
            try:
                with opener.open(URL + '/api/health', timeout=1) as response:
                    state = json.load(response)
                    if state.get('service') == 'zj-comfy-studio' and state.get('instanceId') == process.studio_instance and (expected is None or state.get('version') == expected):
                        return True
            except Exception:
                pass
            time.sleep(.25)
        return False
    process = spawn()
    try:
        if not ready(process):
            print('Studio did not become ready. See the log above.')
            return 1
        print('ZJ Comfy Studio: ' + URL + '\nContinue in the AI Film website. Keep this background service window open. Ctrl+C stops Studio; ComfyUI runs separately.')
        open_entry()
        request_path = ROOT / '.updates/request.json'
        while process.poll() is None:
            if not request_path.exists():
                time.sleep(.5)
                continue
            try:
                request = json.loads(request_path.read_text('utf-8'))
                if not isinstance(request, dict) or not owns_update(request, process):
                    raise ValueError('更新请求不属于当前启动实例，未替换任何程序。请复制诊断信息。')
                staged = valid_staging(ROOT, request.get('staged'))
                if staged is None:
                    raise ValueError('更新暂存目录无效，未替换任何程序。请重新下载更新。')
            except (OSError, ValueError) as exc:
                rejected = ROOT / '.updates' / ('rejected-' + str(time.time_ns()) + '.json')
                if request_path.exists():
                    request_path.replace(rejected)
                write_progress(ROOT, 'failed', str(exc), error=str(exc))
                continue
            # Consume only after validating ownership and staging, never silently discard.
            request_path.unlink()
            write_progress(ROOT, 'applying', '启动器已接手，正在停止旧服务并替换程序')
            stop(process)
            backup = None
            try:
                backup, changed = apply(ROOT, staged)
                write_progress(ROOT, 'restarting', '程序替换完成，正在启动新版本并检查健康状态')
                process = spawn()
                if not ready(process, request['version']):
                    raise RuntimeError('New version did not start')
                result = {'status': 'succeeded', 'version': request['version'], 'message': '更新成功'}
            except Exception as exc:
                stop(process)
                if backup is not None:
                    rollback(ROOT, backup, changed)
                result = {'status': 'rolled_back', 'message': '更新失败，已恢复原版本：' + str(exc)}
                process = spawn()
                if not ready(process):
                    print(result['message'])
                    return 1
            finally:
                import shutil
                shutil.rmtree(staged, ignore_errors=True)
            write_progress(ROOT, result['status'], result['message'], targetVersion=request['version'])
            result['time'] = time.time()
            (ROOT / '.updates/result.json').write_text(json.dumps(result, ensure_ascii=False), 'utf-8')
        return process.returncode
    except KeyboardInterrupt:
        return 0
    finally:
        stop(process)


if __name__ == '__main__':
    raise SystemExit(main())
