"""Explicit, origin-bound browser pairing; ComfyUI remains private on loopback."""
import hashlib
import html
import json
import secrets
import time
from pathlib import Path

from fastapi import File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, Field

from .workflows import digest, normalize, preflight_report
from .updater import VERSION

SITE = 'https://ai-film-shot-studio.chun77129.chatgpt.site'


class BridgeSubmission(BaseModel):
    id: str = Field(pattern=r'^[0-9a-f-]{36}$')
    web_job_id: str = Field(min_length=1, max_length=100)
    graph: dict
    context: dict = Field(default_factory=dict)
    workflow: dict | None = None


def install_bridge(app, store, generate, generate_type, comfy, result, cancel, updater, connection, connection_type):
    device = store.get('config', 'device_id') or secrets.token_hex(16)
    store.put('config', 'device_id', device)
    pairing = {'code': '', 'expires': 0, 'attempts': 0}

    def auth(req):
        if req.headers.get('origin') != SITE:
            raise HTTPException(403, '网页来源未获授权')
        token = req.headers.get('authorization', '').removeprefix('Bearer ')
        expected = store.get('pair', SITE, {}).get('hash', '')
        if not expected or not secrets.compare_digest(hashlib.sha256(token.encode()).hexdigest(), expected):
            raise HTTPException(401, '请先在本机助手取得配对码')

    def owned(req, jid):
        auth(req)
        job = store.get('job', jid)
        if not job or job.get('context', {}).get('bridgeOrigin') != SITE:
            raise HTTPException(404, '本机没有此网页任务，请核对是否使用了另一台电脑')
        return job

    @app.middleware('http')
    async def bridge_cors(req: Request, next_handler):
        if not req.url.path.startswith('/bridge/'):
            return await next_handler(req)
        if req.headers.get('origin') != SITE:
            return JSONResponse({'detail': '网页来源未获授权'}, status_code=403)
        if req.method == 'OPTIONS':
            response = JSONResponse({'ok': True})
            response.headers.update({'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Authorization, Content-Type',
                'Access-Control-Allow-Private-Network': 'true', 'Access-Control-Max-Age': '600'})
        else:
            response = await next_handler(req)
        response.headers['Access-Control-Allow-Origin'] = SITE
        response.headers['Vary'] = 'Origin'
        response.headers['Cache-Control'] = 'no-store'
        return response

    @app.get('/connect', response_class=HTMLResponse)
    async def pairing_page():
        return HTMLResponse('''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>连接镜头台</title>
<style>body{background:#202226;color:#c9cdd2;font:15px/1.8 "Segoe UI",sans-serif;max-width:650px;margin:60px auto;padding:20px}button{background:#4b4539;color:#eadcc0;border:1px solid #b59c6c;padding:10px 20px;margin:6px}output{display:block;font-size:36px;letter-spacing:6px}a{color:#d7c49e}</style>
<h1>ZJ 本地生成助手 · v'''+html.escape(VERSION)+'''</h1><p>配对后，镜头台可以向本机提交 ComfyUI 任务，读取这些任务的进度及结果。</p><p>授权网站：'''+html.escape(SITE)+'''</p>
<button id="pair">取得一次性配对码</button><output id="code"></output><p id="message" role="status">配对码有效期 5 分钟。请回到镜头台输入；重新配对会替换此网站的旧连接。</p>
<button id="revoke">撤销网页连接</button><p><a href="/">打开独立 Studio</a></p>
<script>async function call(path){const r=await fetch(path,{method:'POST'});const d=await r.json();if(!r.ok)throw Error(d.detail||'操作失败');return d}document.getElementById('pair').onclick=async()=>{try{const d=await call('/api/pairing/code');document.getElementById('code').textContent=d.code;document.getElementById('message').textContent='有效期 5 分钟。回到镜头台输入此码，然后点击配对。'}catch(e){document.getElementById('message').textContent=e.message}};document.getElementById('revoke').onclick=async()=>{await call('/api/pairing/revoke');document.getElementById('code').textContent='';document.getElementById('message').textContent='网页连接已撤销。已提交的生成任务仍由 ComfyUI 执行。'}</script></html>''', headers={'Cache-Control': 'no-store', 'Content-Security-Policy': "frame-ancestors 'none'"})

    @app.post('/api/pairing/code')
    async def code():
        pairing.update(code=f'{secrets.randbelow(100000000):08d}', expires=time.monotonic()+300, attempts=0)
        return {'code': pairing['code'], 'expires_in': 300}

    @app.post('/api/pairing/revoke')
    async def revoke():
        store.delete('pair', SITE)
        pairing.update(code='', expires=0)
        return {'ok': True}

    @app.get('/bridge/health')
    async def health():
        return {'service': 'zj-comfy-studio', 'version': VERSION, 'protocol': 1, 'officialKrea': True, 'referenceImages': True, 'browserUpdates': True, 'workspaceIntegration': True}

    @app.post('/bridge/pair')
    async def pair(req: Request):
        data = await req.json()
        pairing['attempts'] += 1
        if pairing['attempts'] > 10 or time.monotonic() > pairing['expires'] or not pairing['code'] or not secrets.compare_digest(str(data.get('code', '')), pairing['code']):
            raise HTTPException(401, '配对码不正确或已过期，请在本机重新取得')
        token = secrets.token_urlsafe(32)
        store.put('pair', SITE, {'hash': hashlib.sha256(token.encode()).hexdigest(), 'at': time.time()})
        pairing.update(code='', expires=0)
        return {'token': token, 'deviceId': device}

    @app.get('/bridge/status')
    async def status(req: Request):
        auth(req)
        try:
            stats = await comfy('GET', '/system_stats')
            return {'deviceId': device, 'comfyOnline': True, 'referenceImages': True, 'devices': stats.get('devices', []), 'version': VERSION, 'workspaceIntegration': True, 'comfyUrl': store.get('config', 'connection', {'url': 'http://127.0.0.1:8188'})['url']}
        except HTTPException as exc:
            return {'deviceId': device, 'comfyOnline': False, 'error': str(exc.detail), 'info': {}, 'version': VERSION, 'workspaceIntegration': True, 'comfyUrl': store.get('config', 'connection', {'url': 'http://127.0.0.1:8188'})['url']}

    @app.get('/bridge/device')
    async def device_info(req: Request):
        auth(req)
        return {'object_info': await comfy('GET', '/object_info'), 'version': VERSION}

    @app.post('/bridge/connection')
    async def configure_connection(req: Request, body: dict):
        auth(req)
        if not isinstance(body.get('url'), str):
            raise HTTPException(422, '请输入 ComfyUI 地址')
        return await connection(connection_type(url=body['url']))

    @app.get('/bridge/workflows')
    async def local_workflows(req: Request):
        auth(req)
        return [{'id': w['id'], 'name': w['name'], 'graph': w['graph'], 'revision': w['revision']}
                for w in store.all('workflow') if w.get('source') != SITE and not w['id'].startswith('web-')]

    @app.post('/bridge/preflight')
    async def check_workflow(req: Request, body: dict):
        auth(req)
        graph = normalize(body.get('graph'))
        info = await comfy('GET', '/object_info')
        report = preflight_report(graph, info)
        return {**report, 'version': VERSION, 'object_info': info}

    @app.post('/bridge/uploads')
    async def upload_reference(req: Request, file: UploadFile = File(...)):
        auth(req)
        content = await file.read(10 * 1024 * 1024 + 1)
        if len(content) > 10 * 1024 * 1024:
            raise HTTPException(413, '单张参考图上限 10MB')
        suffix = {'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp'}.get(file.content_type)
        if not suffix or not content:
            raise HTTPException(422, '参考图请使用 PNG / JPG / WebP')
        # Content-addressed filenames make retries and page reloads deterministic.
        filename = 'zj_ref_' + hashlib.sha256(content).hexdigest() + suffix
        uploaded = await comfy('POST', '/upload/image', files={'image': (filename, content, file.content_type)}, data={'overwrite': 'true', 'type': 'input'})
        name = uploaded.get('name', '')
        folder = uploaded.get('subfolder', '')
        if not name or Path(name).name != name or '..' in Path(folder).parts or folder.startswith('/'):
            raise HTTPException(502, 'ComfyUI 返回的图片名称无效')
        return {'image': (folder + '/' if folder else '') + name}

    @app.post('/bridge/jobs')
    async def submit(req: Request, body: BridgeSubmission):
        auth(req)
        graph = normalize(body.graph)
        existing = store.get('job', body.id)
        if existing:
            old = owned(req, body.id)
            if old['context'].get('webJobId') != body.web_job_id or digest(old['workflow_snapshot']) != digest(graph):
                raise HTTPException(409, '同一任务编号的生成配置不一致')
            return old
        wid = 'web-' + digest(graph)
        store.put('workflow', wid, {'id': wid, 'name': '镜头台 · '+body.web_job_id[:8], 'graph': graph, 'revision': digest(graph), 'created_at': time.time(), 'source': SITE})
        # Reuse Studio's preflight, queue, immutable snapshots and unknown-submit recovery.
        return await generate(generate_type(request_id=body.id, workflow_id=wid, random_seed=False, native_workflow=body.workflow,
            context={**body.context, 'bridgeOrigin': SITE, 'webJobId': body.web_job_id}))

    @app.get('/bridge/jobs/{jid}')
    async def get_job(req: Request, jid: str):
        return owned(req, jid)

    @app.post('/bridge/jobs/{jid}/cancel')
    async def cancel_job(req: Request, jid: str):
        owned(req, jid)
        return await cancel(jid)

    @app.get('/bridge/jobs/{jid}/results/{filename}')
    async def get_result(req: Request, jid: str, filename: str):
        job = owned(req, jid)
        if filename not in {r['file'] for r in job.get('results', [])}:
            raise HTTPException(404)
        return await result(filename)

    @app.get('/bridge/updates/status')
    async def update_status(req: Request):
        auth(req)
        return await updater['status']()

    @app.post('/bridge/updates/install')
    async def update_install(req: Request, release: str = Form(...), archive: UploadFile = File(...)):
        auth(req)
        if len(release) > 64000:
            raise HTTPException(422, '更新信息过大')
        try:
            manifest = json.loads(release)
            if not isinstance(manifest, dict):
                raise ValueError()
        except (ValueError, TypeError):
            raise HTTPException(422, '更新信息无效')
        return await updater['accept'](manifest, archive)
