import base64
import json
import uuid
from pathlib import Path
import httpx
import pytest
from fastapi.testclient import TestClient
from backend.app import create_app, ROOT
from backend.workflows import normalize, preflight

PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jZ9kAAAAASUVORK5CYII=')
GRAPH = json.loads((ROOT / 'workflows/krea2_turbo_api.json').read_text())


class FakeComfy:
    def __init__(self):
        self.pending = []
        self.running = []
        self.history = {}
        self.posts = []
        self.fail_submit = False
        self.lost_response = False
        self.info = {}
        for n in GRAPH.values():
            self.info[n['class_type']] = {'input': {'required': {}}}
        self.info['UNETLoader']['input']['required'] = {'unet_name': [['krea2_turbo_fp8_scaled.safetensors']]}
        self.info['LoraLoaderModelOnly'] = {'input': {'required': {'lora_name': [['test.safetensors']]}}}

    def __call__(self, request):
        path = request.url.path
        if path == '/system_stats':
            return httpx.Response(200, json={'devices': [{'name': 'Mock GPU'}]})
        if path == '/object_info':
            return httpx.Response(200, json=self.info)
        if path == '/prompt':
            body = json.loads(request.content)
            self.posts.append(body)
            if self.fail_submit:
                raise httpx.ConnectError('offline')
            pid = str(uuid.uuid4())
            self.pending.append([1, pid, body['prompt'], body['extra_data'], []])
            if self.lost_response:
                raise httpx.ReadTimeout('response lost after acceptance')
            return httpx.Response(200, json={'prompt_id': pid})
        if path == '/queue':
            if request.method == 'POST':
                ids = json.loads(request.content)['delete']
                self.pending = [q for q in self.pending if q[1] not in ids]
                return httpx.Response(200)
            return httpx.Response(200, json={'queue_pending': self.pending, 'queue_running': self.running})
        if path == '/interrupt':
            pid = json.loads(request.content)['prompt_id']
            assert any(q[1] == pid for q in self.running)
            self.running = [q for q in self.running if q[1] != pid]
            return httpx.Response(200)
        if path == '/history':
            return httpx.Response(200, json=self.history)
        if path.startswith('/history/'):
            pid = path.rsplit('/', 1)[1]
            return httpx.Response(200, json={pid: self.history[pid]} if pid in self.history else {})
        if path == '/view':
            return httpx.Response(200, content=PNG, headers={'content-type': 'image/png'})
        if path == '/upload/image':
            return httpx.Response(200, json={'name': 'ref.png', 'subfolder': '', 'type': 'input'})
        raise AssertionError(f'Unexpected request: {request.method} {path}')

    def finish(self, pid):
        q = next(q for q in self.pending + self.running if q[1] == pid)
        self.pending = [p for p in self.pending if p[1] != pid]
        self.running = [p for p in self.running if p[1] != pid]
        self.history[pid] = {'prompt': q, 'status': {'completed': True, 'status_str': 'success'}, 'outputs': {'9': {'images': [{'filename': 'image.png', 'subfolder': '', 'type': 'output'}]}}}


@pytest.fixture
def rig(tmp_path):
    fake = FakeComfy()
    app = create_app(tmp_path, httpx.MockTransport(fake))
    with TestClient(app) as client:
        yield client, fake, app, tmp_path


def submit(client, **options):
    args = dict(request_id=str(uuid.uuid4()), workflow_id='builtin-krea2-turbo-v1', values={}, random_seed=False)
    args.update(options)
    return client.post('/api/jobs', json=args)


def reconcile(client, app, job):
    # Run the real async history/output recovery code through TestClient's event loop.
    client.portal.call(app.state.reconcile, app.state.store.get('job', job['id']))
    return app.state.store.get('job', job['id'])


def test_submit_snapshot_lora_seed_and_idempotency(rig):
    client, fake, app, _ = rig
    rid = str(uuid.uuid4())
    result = submit(client, request_id=rid, values={'6.text': 'test prompt', '3.seed': 42}, loras=[{'name': 'test.safetensors', 'strength': 0.7}], lora_target='3.model')
    assert result.status_code == 200, result.text
    job = result.json()
    assert job['prompt']['6']['inputs']['text'] == 'test prompt'
    assert job['prompt']['3']['inputs']['seed'] == 42
    assert job['prompt']['zj_lora_0']['inputs']['strength_model'] == 0.7
    assert job['workflow_snapshot']['3']['inputs']['model'] == ['10', 0]
    assert submit(client, request_id=rid).json()['id'] == rid
    assert len(fake.posts) == 1


def test_completion_download_and_clean_removal(rig):
    client, fake, app, directory = rig
    job = submit(client).json()
    fake.finish(job['prompt_id'])
    done = reconcile(client, app, job)
    assert done['status'] == 'completed'
    image = done['results'][0]
    assert client.get(image['url']).content == PNG
    exported = client.get('/api/jobs/'+job['id']+'/export')
    assert exported.json()['prompt_hash'] == job['prompt_hash']
    assert client.delete('/api/jobs/'+job['id']).status_code == 200
    assert not (directory / 'results' / image['file']).exists()
    assert job['prompt_id'] in fake.history


def test_missing_model_blocks_before_submission(rig):
    client, fake, _, _ = rig
    r = submit(client, values={'10.unet_name': 'missing.safetensors'})
    assert r.status_code == 422
    assert '模型或选项不存在' in r.text
    assert not fake.posts


def test_preflight_rejects_missing_required_inputs_and_invalid_source_ports():
    info = {
        'Source': {'input': {'required': {}}, 'output': ['IMAGE']},
        'Target': {'input': {'required': {'image': ['IMAGE', {}], 'mask': ['MASK', {}]}}, 'output': []},
    }
    graph = {
        '1': {'class_type': 'Source', 'inputs': {}},
        '2': {'class_type': 'Target', 'inputs': {'image': ['1', 3]}},
    }
    errors = preflight(graph, info)
    assert any('来源输出端口' in error for error in errors)
    assert any('缺少输入：2.mask' in error for error in errors)
    graph['2']['inputs']['image'] = ['1', 0]
    info['Source']['output'] = ['LATENT']
    assert any('端口类型不兼容' in error for error in preflight(graph, info))


def test_cancel_pending_only_own_prompt(rig):
    client, fake, app, _ = rig
    job = submit(client).json()
    other = [0, 'someone-else', {}, {}, []]
    fake.pending.append(other)
    assert client.post('/api/jobs/'+job['id']+'/cancel').json()['status'] == 'cancelled'
    assert fake.pending == [other]


def test_running_cancellation_scoped(rig):
    client, fake, app, _ = rig
    job = submit(client).json()
    fake.running = [fake.pending.pop()]
    assert client.post('/api/jobs/'+job['id']+'/cancel').json()['status'] == 'cancelling'
    assert reconcile(client, app, job)['status'] == 'cancelled'


def test_lost_submission_response_recovers_without_duplicate(rig):
    client, fake, app, _ = rig
    fake.lost_response = True
    rid = str(uuid.uuid4())
    job = submit(client, request_id=rid).json()
    assert job['status'] == 'submission_unknown'
    recovered = reconcile(client, app, job)
    assert recovered['prompt_id'] == fake.pending[0][1]
    assert recovered['status'] == 'queued'
    assert submit(client, request_id=rid).json()['prompt_id'] == recovered['prompt_id']
    assert len(fake.posts) == 1


def test_disconnect_retains_unknown_and_cannot_switch_device(rig):
    client, fake, app, _ = rig
    fake.fail_submit = True
    job = submit(client).json()
    assert job['status'] == 'submission_unknown'
    assert client.post('/api/connection', json={'url': 'http://192.168.1.7:8188'}).status_code == 409
    assert client.delete('/api/jobs/'+job['id']).status_code == 409


def test_restart_preserves_snapshots_and_history_recovery(tmp_path):
    fake = FakeComfy()
    app = create_app(tmp_path, httpx.MockTransport(fake))
    with TestClient(app) as client:
        job = submit(client).json()
    fake.finish(job['prompt_id'])
    second = create_app(tmp_path, httpx.MockTransport(fake))
    with TestClient(second) as client:
        done = reconcile(client, second, job)
        assert done['status'] == 'completed'
        assert done['workflow_revision'] == job['workflow_revision']
        assert client.get(done['results'][0]['url']).status_code == 200


def test_import_formats_security_and_upload(rig):
    client, _, _, _ = rig
    assert client.post('/api/workflows', json={'name': 'bad', 'workflow': {'nodes': []}}).status_code == 422
    assert client.post('/api/workflows', json={'name': 'copy', 'workflow': GRAPH}).json()['id'] == 'builtin-krea2-turbo-v1'
    assert client.post('/api/connection', json={'url': 'file:///etc/passwd'}).status_code == 422
    assert client.post('/api/jobs', json={}, headers={'Origin': 'https://evil.example'}).status_code == 403
    assert client.get('/api/state', headers={'Host': 'evil.example'}).status_code == 400
    assert client.post('/api/uploads', files={'file': ('test.png', PNG, 'image/png')}).json()['name'] == 'ref.png'
    assert client.post('/api/uploads', files={'file': ('test.html', b'<h1>', 'text/html')}).status_code == 422
    assert submit(client, request_id='../../outside-path').status_code == 422
    assert client.get('/').status_code == 200


def test_error_and_interruption_history(rig):
    client, fake, app, _ = rig
    job = submit(client).json()
    fake.history[job['prompt_id']] = {'status': {'status_str': 'error', 'messages': [['execution_error', {'exception_message': 'CUDA out of memory'}]]}}
    done = reconcile(client, app, job)
    assert done['status'] == 'failed'
    assert 'CUDA out of memory' in done['error']
    second = submit(client).json()
    fake.history[second['prompt_id']] = {'status': {'status_str': 'error', 'messages': [['execution_interrupted', {}]]}}
    assert reconcile(client, app, second)['status'] == 'cancelled'


def test_workflow_removal_keeps_job_snapshot_and_reuse(rig):
    client, _, app, _ = rig
    job = submit(client).json()
    assert client.delete('/api/workflows/'+job['workflow_id']).status_code == 200
    record = client.get('/api/jobs/'+job['id']+'/export').json()
    assert record['workflow_snapshot'] == GRAPH
    restored = client.post('/api/workflows', json={'name': 'restored', 'workflow': record['workflow_snapshot']})
    assert restored.status_code == 200
    assert restored.json()['revision'] == job['workflow_revision']


def test_edited_parameter_types_and_links_are_protected(rig):
    client, fake, _, _ = rig
    assert submit(client, values={'3.model': ['10', 0]}).status_code == 422
    assert submit(client, values={'3.seed': 'not an integer'}).status_code == 422
    assert submit(client, values={'5.width': True}).status_code == 422
    assert not fake.posts


def test_resolve_unknown_requires_confirmation_and_rechecks_queue(rig):
    client, fake, app, _ = rig
    fake.fail_submit = True
    job = submit(client).json()
    path = '/api/jobs/'+job['id']+'/resolve-unknown'
    assert client.post(path, json={}).status_code == 422
    resolved = client.post(path, json={'confirmed_no_task': True})
    assert resolved.json()['status'] == 'failed'
    assert client.delete('/api/jobs/'+job['id']).status_code == 200
    fake.fail_submit = False
    fake.lost_response = True
    accepted = submit(client).json()
    assert client.post('/api/jobs/'+accepted['id']+'/resolve-unknown', json={'confirmed_no_task': True}).status_code == 409
    assert app.state.store.get('job', accepted['id'])['prompt_id']
