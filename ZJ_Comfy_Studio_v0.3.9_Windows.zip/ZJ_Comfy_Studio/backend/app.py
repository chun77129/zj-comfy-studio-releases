"""Loopback-only local studio. No cloud keys or model installation required."""
import asyncio
import contextlib
import json
import os
import secrets
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlparse

import httpx
from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.middleware.trustedhost import TrustedHostMiddleware
from websockets.asyncio.client import connect

from .store import Store
from .workflows import add_loras, apply_values, digest, fields, normalize, preflight

ROOT = Path(__file__).resolve().parent.parent
ACTIVE = {'submitting', 'submission_unknown', 'queued', 'running', 'disconnected', 'cancelling'}


class Connection(BaseModel):
    url: str


class WorkflowImport(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    workflow: dict


class Lora(BaseModel):
    name: str
    strength: float = Field(ge=-4, le=4)


class Generate(BaseModel):
    request_id: str = Field(pattern=r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    workflow_id: str
    values: dict = Field(default_factory=dict)
    random_seed: bool = True
    loras: list[Lora] = Field(default_factory=list, max_length=20)
    lora_target: str = ''
    context: dict = Field(default_factory=dict)
    native_workflow: dict | None = None


def create_app(data_dir=None, transport=None):
    store = Store(data_dir or os.environ.get('ZJ_STUDIO_DATA', str(ROOT / 'data')))
    client = httpx.AsyncClient(transport=transport, timeout=20, trust_env=False)
    mutation_lock = asyncio.Lock()
    client_id = store.get('config', 'client_id') or str(uuid.uuid4())
    store.put('config', 'client_id', client_id)
    ws_state = {'connected': False}

    def url():
        return store.get('config', 'connection', {'url': 'http://127.0.0.1:8188'})['url']

    async def comfy(method, path, base=None, **kwargs):
        try:
            response = await client.request(method, (base or url()) + path, **kwargs)
            response.raise_for_status()
            return response.json() if response.content else {}
        except httpx.HTTPStatusError as exc:
            raise HTTPException(502, f'ComfyUI {exc.response.status_code}: {exc.response.text[:1800]}') from exc
        except (httpx.RequestError, ValueError) as exc:
            raise HTTPException(503, f'无法连接 ComfyUI：{exc}') from exc

    def patch(job, **values):
        job.update(values, updated_at=time.time())
        return store.put('job', job['id'], job)

    async def save_outputs(job, entry):
        results = []
        existing = {r['source_key']: r for r in job.get('results', [])}
        for nid, output in entry.get('outputs', {}).items():
            for image in output.get('images', []):
                key = json.dumps([nid, image], sort_keys=True)
                if key in existing:
                    results.append(existing[key])
                    continue
                if image.get('type', 'output') != 'output':
                    continue
                response = await client.get(job['device_url'] + '/view', params={k: image.get(k, '') for k in ['filename', 'subfolder', 'type']})
                response.raise_for_status()
                suffix = Path(image['filename']).suffix.lower()
                if suffix not in {'.png', '.jpg', '.jpeg', '.webp', '.avif'}:
                    suffix = '.png'
                filename = f"{job['id']}_{len(results):03}{suffix}"
                tmp = store.root / 'results' / (filename + '.part')
                tmp.write_bytes(response.content)
                tmp.replace(store.root / 'results' / filename)
                results.append({'file': filename, 'source': image, 'source_key': key, 'url': '/api/results/' + filename})
                patch(job, results=results)
        return results

    async def reconcile(job):
        base = job['device_url']
        pid = job.get('prompt_id')
        if not pid:
            # A timed-out submission must not be sent twice. Recover it by our job marker.
            history = await comfy('GET', '/history?max_items=200', base=base)
            queue = await comfy('GET', '/queue', base=base)
            candidates = [e.get('prompt', []) for e in history.values()] + queue.get('queue_running', []) + queue.get('queue_pending', [])
            for item in candidates:
                if len(item) > 3 and item[3].get('zj_job_id') == job['id']:
                    pid = item[1]
                    patch(job, prompt_id=pid)
                    break
            if not pid:
                patch(job, status='submission_unknown', error='提交结果未确认。请先到 ComfyUI 核对队列／历史，再决定是否重新生成，系统不会自动重送。')
                return
        history = await comfy('GET', '/history/' + pid, base=base)
        entry = history.get(pid)
        if entry:
            status = entry.get('status', {})
            if status.get('status_str') == 'error':
                messages = status.get('messages', [])
                interrupted = any(m[0] == 'execution_interrupted' for m in messages)
                patch(job, status='cancelled' if interrupted else 'failed', error=json.dumps(messages, ensure_ascii=False)[-5000:])
                return
            if status.get('completed') or status.get('status_str') == 'success':
                # The official PreviewAny node is a native text output in ComfyUI history.
                # Never infer enhanced text when the runtime did not return it.
                preview = entry.get('outputs', {}).get('30:20', {}).get('text', [])
                graph = job['prompt']
                if isinstance(preview, list) and preview and isinstance(preview[0], str) and '30:19' in graph:
                    actual_text = preview[0]
                    lora = graph.get('30:27', {}).get('inputs')
                    if lora:
                        actual_text += str(lora.get('delimiter', '')) + str(lora.get('string_b', ''))
                    patch(job, prompt_texts={'original': graph['30:19']['inputs'].get('value', ''),
                        'before_style': preview[0], 'final': actual_text})
                results = await save_outputs(job, entry)
                patch(job, status='completed' if results else 'failed', progress=100,
                      results=results, error='' if results else '工作流执行完毕，但没有 SaveImage 输出图片。')
                return
        queue = await comfy('GET', '/queue', base=base)
        running = any(x[1] == pid for x in queue.get('queue_running', []))
        pending = any(x[1] == pid for x in queue.get('queue_pending', []))
        if running:
            patch(job, status='cancelling' if job.get('cancel_requested') else 'running', error='')
        elif pending:
            patch(job, status='queued', error='')
        elif job.get('cancel_requested'):
            patch(job, status='cancelled', error='')
        elif time.time() - job['created_at'] > 15:
            patch(job, status='failed', error='任务已不在 ComfyUI 队列或历史中，可能被清除或引擎重启。可重新生成。')

    async def monitor():
        while True:
            async with mutation_lock:
                for job in store.all('job'):
                    if job['status'] not in ACTIVE:
                        continue
                    try:
                        await reconcile(job)
                    except (HTTPException, httpx.HTTPError) as exc:
                        patch(job, status='disconnected', error=getattr(exc, 'detail', str(exc)))
            await asyncio.sleep(1.5)

    async def events():
        while True:
            base = url()
            try:
                endpoint = base.replace('http://', 'ws://', 1).replace('https://', 'wss://', 1) + '/ws?clientId=' + client_id
                async with connect(endpoint, max_size=16 * 1024 * 1024, proxy=None) as ws:
                    ws_state['connected'] = True
                    async for raw in ws:
                        if base != url():
                            break
                        if isinstance(raw, bytes):
                            continue
                        event = json.loads(raw)
                        data = event.get('data', {})
                        if event.get('type') not in {'progress', 'executing'}:
                            continue
                        async with mutation_lock:
                            for job in store.all('job'):
                                if job['status'] not in ACTIVE or job['device_url'] != base or job.get('prompt_id') != data.get('prompt_id'):
                                    continue
                                values = {'node': str(data.get('node', job.get('node', '')))}
                                if event['type'] == 'progress' and data.get('max'):
                                    values.update(progress=round(data['value'] / data['max'] * 100), step=data['value'], total_steps=data['max'])
                                patch(job, **values)
            except Exception:
                # Connection loss leaves the HTTP history monitor running.
                ws_state['connected'] = False
            await asyncio.sleep(2)

    @asynccontextmanager
    async def lifespan(app):
        tasks = [asyncio.create_task(monitor())]
        if transport is None:
            tasks.append(asyncio.create_task(events()))
        yield
        for task in tasks:
            task.cancel()
        for task in tasks:
            with contextlib.suppress(asyncio.CancelledError):
                await task
        await client.aclose()
        store.db.close()

    app = FastAPI(title='ZJ Comfy Studio', version='0.3.9', lifespan=lifespan)
    app.state.store = store
    app.state.reconcile = reconcile
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=['127.0.0.1', 'localhost', '[::1]', 'testserver'])

    @app.middleware('http')
    async def local_origin(request: Request, call_next):
        if request.method not in {'GET', 'HEAD', 'OPTIONS'}:
            origin = request.headers.get('origin')
            if origin and origin != str(request.base_url).rstrip('/') and not request.url.path.startswith('/bridge/'):
                return JSONResponse({'detail': '只接受本地同源界面操作'}, status_code=403)
        return await call_next(request)

    default_id = 'builtin-krea2-turbo-v1'
    if not store.get('config', 'workflows_initialized', False):
        graph = normalize(json.loads((ROOT / 'workflows/krea2_turbo_api.json').read_text()))
        store.put('workflow', default_id, dict(id=default_id, name='Krea 2 Turbo · 基础文生图', graph=graph,
                    revision=digest(graph), created_at=time.time(), source='Comfy-Org/workflow_templates · 官方节点精简版；扩写关闭；768px 起测'))
        store.put('config', 'workflows_initialized', True)

    @app.get('/api/health')
    async def health():
        return {'service': 'zj-comfy-studio', 'version': '0.3.9'}

    @app.get('/api/state')
    async def state():
        return {'connection': {'url': url()}, 'workflows': store.all('workflow'), 'jobs': store.all('job'), 'events_connected': ws_state['connected']}

    @app.post('/api/connection')
    async def connection(body: Connection):
        parsed = urlparse(body.url.strip())
        if parsed.scheme not in {'http', 'https'} or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in {'', '/'}:
            raise HTTPException(422, '请输入 ComfyUI 的 http(s) 地址，不含密码、路径或查询参数')
        base = body.url.strip().rstrip('/')
        async with mutation_lock:
            if any(j['status'] in ACTIVE for j in store.all('job')) and base != url():
                raise HTTPException(409, '有未结束任务，请完成或取消后再更换设备')
            stats = await comfy('GET', '/system_stats', base=base)
            info = await comfy('GET', '/object_info', base=base)
            store.put('config', 'connection', {'url': base})
        return {'connected': True, 'stats': stats, 'node_count': len(info)}

    @app.get('/api/device')
    async def device():
        stats, info = await asyncio.gather(comfy('GET', '/system_stats'), comfy('GET', '/object_info'))
        return {'connected': True, 'stats': stats, 'object_info': info}

    @app.post('/api/workflows')
    async def import_workflow(body: WorkflowImport):
        graph = normalize(body.workflow)
        revision = digest(graph)
        for w in store.all('workflow'):
            if w['revision'] == revision:
                return w
        wid = str(uuid.uuid4())
        return store.put('workflow', wid, {'id': wid, 'name': body.name, 'graph': graph,
                         'revision': revision, 'created_at': time.time(), 'source': '导入 API JSON'})

    @app.delete('/api/workflows/{wid}')
    async def delete_workflow(wid: str):
        store.delete('workflow', wid)
        return {'deleted': True}

    @app.get('/api/workflows/{wid}/fields')
    async def get_fields(wid: str):
        w = store.get('workflow', wid)
        if not w:
            raise HTTPException(404, '工作流不存在')
        return fields(w['graph'])

    @app.post('/api/jobs')
    async def generate(body: Generate):
        async with mutation_lock:
            if getattr(app.state, 'updating', False):
                raise HTTPException(409, 'Studio 正在更新，请重启后再生成')
            old = store.get('job', body.request_id)
            if old:
                return old
            w = store.get('workflow', body.workflow_id)
            if not w:
                raise HTTPException(404, '请先选择工作流')
            graph = apply_values(w['graph'], body.values)
            if body.random_seed:
                for f in fields(graph):
                    if f['input'] in {'seed', 'noise_seed'}:
                        graph[f['node']]['inputs'][f['input']] = secrets.randbelow(2**48)
            graph = add_loras(graph, [l.model_dump() for l in body.loras], body.lora_target)
            info = await comfy('GET', '/object_info')
            errors = preflight(graph, info)
            if errors:
                raise HTTPException(422, {'message': '生成前检查未通过', 'errors': errors})
            now = time.time()
            job = dict(id=body.request_id, workflow_id=w['id'], workflow_name=w['name'], workflow_revision=w['revision'],
                       workflow_snapshot=w['graph'], prompt=graph, prompt_hash=digest(graph), device_url=url(),
                       values=body.values, loras=[l.model_dump() for l in body.loras], lora_target=body.lora_target,
                       context=body.context, native_workflow=body.native_workflow, created_at=now, updated_at=now, status='submitting', progress=0, results=[], error='')
            store.put('job', job['id'], job)
            try:
                response = await comfy('POST', '/prompt', json={'prompt': graph, 'client_id': client_id, 'extra_data': {'zj_job_id': job['id'], **({'extra_pnginfo': {'workflow': body.native_workflow}} if body.native_workflow else {})}})
                if not response.get('prompt_id'):
                    return patch(job, status='failed', error=json.dumps(response, ensure_ascii=False))
                return patch(job, status='queued', prompt_id=response['prompt_id'])
            except HTTPException as exc:
                # Timeouts may occur after acceptance. Never auto-resubmit.
                return patch(job, status='submission_unknown' if exc.status_code == 503 else 'failed', error=str(exc.detail))

    @app.post('/api/jobs/{jid}/cancel')
    async def cancel(jid: str):
        async with mutation_lock:
            job = store.get('job', jid)
            if not job:
                raise HTTPException(404, '任务不存在')
            if job['status'] not in ACTIVE:
                return job
            await reconcile(job)
            job = store.get('job', jid)
            pid = job.get('prompt_id')
            if not pid:
                raise HTTPException(409, '提交状态未知，请先在 ComfyUI 确认；不会中断其他任务')
            queue = await comfy('GET', '/queue', base=job['device_url'])
            if any(x[1] == pid for x in queue.get('queue_pending', [])):
                await comfy('POST', '/queue', base=job['device_url'], json={'delete': [pid]})
                patch(job, status='cancelled', cancel_requested=True)
            elif any(x[1] == pid for x in queue.get('queue_running', [])):
                # prompt_id makes this scoped on modern ComfyUI. Verify again immediately first.
                await comfy('POST', '/interrupt', base=job['device_url'], json={'prompt_id': pid})
                patch(job, status='cancelling', cancel_requested=True)
            return job

    @app.post('/api/jobs/{jid}/resolve-unknown')
    async def resolve_unknown(jid: str, request: Request):
        body = await request.json()
        if body.get('confirmed_no_task') is not True:
            raise HTTPException(422, '请先在 ComfyUI 确认没有对应任务')
        async with mutation_lock:
            job = store.get('job', jid)
            if not job or job.get('prompt_id') or job['status'] not in {'submission_unknown', 'disconnected'}:
                raise HTTPException(409, '仅能处理没有 prompt_id 的待核对记录')
            await reconcile(job)
            job = store.get('job', jid)
            if job.get('prompt_id'):
                raise HTTPException(409, '已找到对应 ComfyUI 任务，请使用正常取消或等待完成')
            return patch(job, status='failed', error='用户已在 ComfyUI 核对并确认无对应任务；手动结束待核对记录。', resolved_unknown_at=time.time())

    @app.get('/api/jobs/{jid}/export')
    async def export(jid: str):
        job = store.get('job', jid)
        if not job:
            raise HTTPException(404, '任务不存在')
        return JSONResponse(job, headers={'Content-Disposition': f'attachment; filename="zj-generation-{jid}.json"'})

    @app.delete('/api/jobs/{jid}')
    async def delete_job(jid: str):
        async with mutation_lock:
            job = store.get('job', jid)
            if not job:
                raise HTTPException(404, '任务不存在')
            if job['status'] in ACTIVE:
                raise HTTPException(409, '请先结束任务')
            for result in job.get('results', []):
                (store.root / 'results' / Path(result['file']).name).unlink(missing_ok=True)
            store.delete('job', jid)
        return {'deleted': True, 'note': '已删除 Studio 记录与结果副本；ComfyUI 原始输出保留'}

    @app.post('/api/uploads')
    async def upload(file: UploadFile = File(...)):
        content = await file.read(30 * 1024 * 1024 + 1)
        if len(content) > 30 * 1024 * 1024:
            raise HTTPException(413, '单张参考图上限 30MB')
        if file.content_type not in {'image/png', 'image/jpeg', 'image/webp'}:
            raise HTTPException(422, '参考图请使用 PNG / JPG / WebP')
        suffix = {'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp'}[file.content_type]
        return await comfy('POST', '/upload/image', files={'image': (str(uuid.uuid4()) + suffix, content, file.content_type)})

    @app.get('/api/results/{filename}')
    async def result(filename: str):
        if Path(filename).name != filename:
            raise HTTPException(404)
        p = store.root / 'results' / filename
        if not p.is_file():
            raise HTTPException(404)
        return FileResponse(p)

    from .updater import install_routes
    updater = install_routes(app, ROOT, store, mutation_lock, ACTIVE)
    from .bridge import install_bridge
    install_bridge(app, store, generate, Generate, comfy, result, cancel, updater)

    static = ROOT / 'frontend' / 'dist'
    if static.is_dir():
        app.mount('/', StaticFiles(directory=static, html=True), name='frontend')
    return app


app = create_app()
