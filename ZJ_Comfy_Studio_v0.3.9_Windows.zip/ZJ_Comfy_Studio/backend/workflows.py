"""API-format workflows, immutable snapshots, explicit editable scalar inputs."""
import copy
import hashlib
import json
from fastapi import HTTPException


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def normalize(raw):
    if not isinstance(raw, dict):
        raise HTTPException(422, '工作流必须是 JSON 对象')
    if 'nodes' in raw or 'definitions' in raw:
        raise HTTPException(422, '这是画布格式。请在 ComfyUI 中选择「文件 → 导出（API）」后重新导入；不能直接执行含子图的画布 JSON。')
    graph = raw.get('prompt', raw)
    if not isinstance(graph, dict) or not graph or len(graph) > 1000:
        raise HTTPException(422, '无效或过大的 API 工作流')
    for key, node in graph.items():
        if not isinstance(node, dict) or not isinstance(node.get('class_type'), str) or not isinstance(node.get('inputs'), dict):
            raise HTTPException(422, f'节点 {key} 缺少 class_type / inputs，请使用 API 格式')
        for value in node['inputs'].values():
            if isinstance(value, list) and (len(value) != 2 or str(value[0]) not in graph or not isinstance(value[1], int)):
                raise HTTPException(422, f'节点 {key} 存在无效连接')
    return copy.deepcopy(graph)


def fields(graph):
    result = []
    for nid, node in graph.items():
        title = node.get('_meta', {}).get('title', node['class_type'])
        for key, value in node['inputs'].items():
            if isinstance(value, (str, int, float, bool)):
                result.append(dict(id=f'{nid}.{key}', node=nid, input=key, title=title,
                                   class_type=node['class_type'], value=value))
    return result


def apply_values(graph, values):
    graph = copy.deepcopy(graph)
    editable = {f['id']: f for f in fields(graph)}
    for key, value in values.items():
        f = editable.get(key)
        if f is None:
            raise HTTPException(422, f'参数不存在或是连线：{key}')
        old = f['value']
        if isinstance(old, bool):
            valid = isinstance(value, bool)
        elif isinstance(old, int):
            valid = isinstance(value, int) and not isinstance(value, bool)
        elif isinstance(old, float):
            valid = isinstance(value, (int, float)) and not isinstance(value, bool)
        else:
            valid = isinstance(value, str)
        if not valid:
            raise HTTPException(422, f'参数类型不符：{key}')
        graph[f['node']]['inputs'][f['input']] = value
    return graph


def add_loras(graph, loras, target):
    if not loras:
        return graph
    if not target or '.' not in target:
        raise HTTPException(422, '请先指定 LoRA 的模型输入位置')
    nid, key = target.split('.', 1)
    link = graph.get(nid, {}).get('inputs', {}).get(key)
    if key != 'model' or not isinstance(link, list):
        raise HTTPException(422, 'LoRA 目标必须是 model 连线输入')
    graph = copy.deepcopy(graph)
    for index, lora in enumerate(loras):
        lid = f'zj_lora_{index}'
        while lid in graph:
            lid += '_'
        graph[lid] = {'class_type': 'LoraLoaderModelOnly', 'inputs': {
            'model': link, 'lora_name': lora['name'], 'strength_model': lora['strength']}}
        link = [lid, 0]
    graph[nid]['inputs'][key] = link
    return graph


def preflight(graph, info):
    errors = []
    for nid, node in graph.items():
        spec = info.get(node['class_type'])
        if not spec:
            errors.append(f"缺少节点：{node['class_type']}（{nid}）")
            continue
        if spec.get('api_node') or node['class_type'].lower().startswith(('openai', 'gemini')):
            errors.append(f"第一版不执行付费 API 节点：{node['class_type']}")
        inputs = spec.get('input', {})
        required = inputs.get('required', {})
        for key, rule in {**required, **inputs.get('optional', {})}.items():
            value = node['inputs'].get(key)
            if key not in node['inputs']:
                if key in required:
                    errors.append(f'缺少输入：{nid}.{key}')
                continue
            if value is None and key in required:
                errors.append(f'缺少输入：{nid}.{key}')
            elif isinstance(value, list):
                source_id, output_index = str(value[0]), value[1]
                source = graph.get(source_id)
                source_spec = info.get(source.get('class_type')) if source else None
                outputs = source_spec.get('output', []) if source_spec else []
                if not isinstance(output_index, int) or output_index < 0 or output_index >= len(outputs):
                    errors.append(f'来源输出端口无效：{nid}.{key} <- {source_id}[{output_index}]')
                    continue
                expected = rule[0] if isinstance(rule, list) and rule else None
                actual = outputs[output_index]
                if isinstance(expected, str) and expected not in {'*', 'ANY'} and actual not in {'*', 'ANY'} and expected != actual:
                    errors.append(f'端口类型不兼容：{nid}.{key} 需要 {expected}，来源为 {actual}')
            elif isinstance(rule, list) and rule and isinstance(rule[0], list) and value not in rule[0]:
                errors.append(f'模型或选项不存在：{nid}.{key} = {value}')
    return errors
