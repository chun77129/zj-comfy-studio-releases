$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
$source = Split-Path $PSScriptRoot -Parent
$destination = Join-Path $env:LOCALAPPDATA 'ZJComfyStudio'
function Has-CompatiblePython {
    $previousPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        if (Get-Command py -ErrorAction SilentlyContinue) {
            foreach ($v in @('-3.12', '-3.13', '-3.11', '-3.10')) {
                & py $v -c 'import sys; assert (3,10) <= sys.version_info < (3,14)' 2>&1 | Out-Null
                if ($LASTEXITCODE -eq 0) { return $true }
            }
        }
        if (Get-Command python -ErrorAction SilentlyContinue) {
            & python -c 'import sys; assert (3,10) <= sys.version_info < (3,14)' 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) { return $true }
        }
        return $false
    } finally { $ErrorActionPreference = $previousPreference }
}
try {
    if (-not (Test-Path (Join-Path $source 'frontend\dist\index.html'))) { throw 'Fully extract the ZIP before running install.cmd.' }
    try {
        $running = Invoke-RestMethod 'http://127.0.0.1:8765/api/health' -TimeoutSec 2
    } catch { $running = $null }
    if ($running) {
        if ($running.service -ne 'zj-comfy-studio') { throw 'Port 8765 belongs to another program. No process was stopped.' }
        $state = Invoke-RestMethod 'http://127.0.0.1:8765/api/state' -TimeoutSec 5
        $activeStates = @('submitting','submission_unknown','queued','running','disconnected','cancelling')
        if (@($state.jobs | Where-Object { $_.status -in $activeStates }).Count -gt 0) {
            throw 'Studio has unfinished jobs. Finish or resolve them before installing. No process was stopped.'
        }
        $listeners = @(Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction Stop | Select-Object -ExpandProperty OwningProcess -Unique)
        foreach ($studioPid in $listeners) {
            $studioProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $studioPid"
            $cmd = [string]$studioProcess.CommandLine
            $knownLocation = $cmd.IndexOf($destination, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or $cmd.IndexOf($source, [StringComparison]::OrdinalIgnoreCase) -ge 0
            if ($cmd -notmatch 'uvicorn\s+backend\.app:app' -or -not $knownLocation) {
                throw 'Studio is running from an unrecognized location. Close its original terminal before installing. No process was stopped.'
            }
        }
        Write-Host 'Stopping idle Studio for upgrade. ComfyUI stays running...'
        foreach ($studioPid in $listeners) { Stop-Process -Id $studioPid -Force -ErrorAction Stop }
        for ($attempt = 0; $attempt -lt 30; $attempt++) {
            if (-not (Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue)) { break }
            Start-Sleep -Milliseconds 200
        }
        if (Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue) {
            throw 'Studio port is still busy. Installation stopped before copying files.'
        }
    }
    if (-not (Has-CompatiblePython)) {
        Write-Host 'Installing Python 3.12 for Studio...'
        $previousPreference = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        if (Get-Command py -ErrorAction SilentlyContinue) { & py install 3.12 }
        $ErrorActionPreference = $previousPreference
        if (-not (Has-CompatiblePython)) {
            if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { throw 'Install Python 3.12 from https://www.python.org/downloads/windows/ then run install.cmd again.' }
            & winget install --id Python.Python.3.12 --exact --scope user --accept-source-agreements --accept-package-agreements
            if ($LASTEXITCODE -ne 0) { throw 'Python installation failed. See the message above.' }
            # Refresh PATH after the per-user installer, without requiring a new terminal.
            $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine')+';'+[Environment]::GetEnvironmentVariable('Path','User')
            if (-not (Has-CompatiblePython)) { throw 'Python installed. Close this window and run install.cmd again to refresh the launcher.' }
        }
    }
    New-Item -ItemType Directory -Force -Path $destination | Out-Null
    if ([IO.Path]::GetFullPath($source).TrimEnd('\') -ne [IO.Path]::GetFullPath($destination).TrimEnd('\')) {
        & robocopy $source $destination /E /XD .venv node_modules .git __pycache__ .pytest_cache data /XF '*.pyc' | Out-Null
        if ($LASTEXITCODE -ge 8) { throw 'Could not copy Studio files.' }
    }
    $launch = Join-Path $destination 'start.bat'
    $key = 'HKCU:\Software\Classes\zjcomfystudio'
    New-Item -Path "$key\shell\open\command" -Force | Out-Null
    Set-Item -Path $key -Value 'URL:ZJ Comfy Studio'
    New-ItemProperty -Path $key -Name 'URL Protocol' -Value '' -PropertyType String -Force | Out-Null
    # No URI arguments reach a shell: external links can only open this fixed launcher.
    Set-Item -Path "$key\shell\open\command" -Value ('"'+$env:ComSpec+'" /d /c ""'+$launch+'""')
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'ZJ Comfy Studio.lnk'))
    $shortcut.TargetPath = $launch
    $shortcut.WorkingDirectory = $destination
    $shortcut.Save()
    Write-Host 'Installed. Return to the website after Studio starts. Open http://127.0.0.1:8765/connect to get a pairing code.'
    & $launch
} catch {
    Write-Host $_ -ForegroundColor Red
    Read-Host 'Press Enter to close'
    exit 1
}
