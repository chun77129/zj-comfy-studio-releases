$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
$env:PYTHONUTF8 = '1'
try {
    if (-not (Test-Path '.venv\Scripts\python.exe')) {
        $pythonCommand = $null
        $pythonVersion = $null
        # Probe without treating a missing optional interpreter as a fatal native stderr error.
        $previousPreference = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        if (Get-Command py -ErrorAction SilentlyContinue) {
            foreach ($version in @('-3.12', '-3.13', '-3.11', '-3.10')) {
                & py $version -c 'import sys; assert (3,10) <= sys.version_info < (3,14)' 2>&1 | Out-Null
                if ($LASTEXITCODE -eq 0) { $pythonCommand = 'py'; $pythonVersion = $version; break }
            }
        }
        if (-not $pythonCommand -and (Get-Command python -ErrorAction SilentlyContinue)) {
            & python -c 'import sys; assert (3,10) <= sys.version_info < (3,14)' 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) { $pythonCommand = 'python' }
        }
        $ErrorActionPreference = $previousPreference
        if ($pythonCommand -eq 'py') { & py $pythonVersion -m venv .venv }
        elseif ($pythonCommand -eq 'python') { & python -m venv .venv }
        else { throw 'No compatible Python found. Run install.cmd to install Python and set up Studio.' }
        if ($LASTEXITCODE -ne 0) { throw 'Could not create the isolated Python environment.' }
    }
    $pythonPath = Join-Path (Get-Location) '.venv\Scripts\python.exe'
    $hash = (Get-FileHash 'requirements.txt' -Algorithm SHA256).Hash
    $marker = '.venv\studio-requirements.sha256'
    if (-not (Test-Path $marker) -or (Get-Content $marker -Raw).Trim() -ne $hash) {
        Write-Host 'First start: installing Studio dependencies into .venv (ComfyUI is unchanged)...'
        & $pythonPath -m pip install -r requirements.txt
        if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check internet access, then run start.bat again.' }
        Set-Content -Path $marker -Value $hash -Encoding ascii
    }
    & $pythonPath scripts\launch.py
    if ($LASTEXITCODE -ne 0) { throw 'Studio stopped with an error. See the message above.' }
} catch {
    Write-Host $_ -ForegroundColor Red
    Read-Host 'Press Enter to close'
    exit 1
}
