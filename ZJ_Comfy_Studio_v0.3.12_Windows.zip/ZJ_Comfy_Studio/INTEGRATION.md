# ZJ Comfy Studio v0.2 网页配对协议

网站来源固定为 https://ai-film-shot-studio.chun77129.chatgpt.site，助手仅监听 127.0.0.1:8765。

- `GET /connect`：本机配对页；POST `/api/pairing/code` 由同源页面取得五分钟一次性码，十次错误后需重新取得。
- `POST /bridge/pair {code}`：验证来源及配对码，返回 token/deviceId；本机只存令牌哈希。重新配对替换旧授权。
- `GET /bridge/status`：令牌认证，返回 deviceId、ComfyUI 状态。
- `POST /bridge/jobs {id,web_job_id,graph,workflow?,context}`：冻结适配后的 API prompt；`workflow` 可携带原 UI 画布用于 ComfyUI 元数据。提交前验证节点、必需输入、模型/枚举、来源输出槽和端口类型，再复用持久化队列。相同 UUID 和图只提交一次；同 UUID 配置变化拒绝。
- `GET /bridge/jobs/{id}`：只读取此来源创建的网页任务。
- `POST /bridge/jobs/{id}/cancel`：仅取消该任务。
- `GET /bridge/jobs/{id}/results/{filename}`：只读取该任务输出列表中的图片。
- `POST /api/pairing/revoke`：本机撤销网站授权。已提交任务继续执行。

所有 /bridge 请求均验证精确 Origin；除 health/pair 外，需 Authorization: Bearer。CORS 限定单一网站、路径、方法和头，不开放普通 /api 管理接口。TrustedHostMiddleware 防止非本机 Host。

网页负责把已验证的 UI 画布映射为 API prompt；Studio 不猜测转换任意画布。Studio 仍以本机 `/object_info` 为最终依赖依据，缺少自定义节点、模型、LoRA 或确定的端口不兼容时返回 422，且不会调用 ComfyUI `/prompt`。

网页记录包含冻结 API 图、固定 Seed、设备 ID、本机 UUID。网页以同 UUID 幂等恢复，提交超时使用现有待核对机制，不能自动创建第二个 UUID 重试。

结果通过浏览器回传 `/api/studio-results`，按网页任务/本机 UUID/文件名确定去重键，使用修订号 CAS 写入候选区；不自动采用。每张上限 10 MB，支持 PNG/JPEG/WebP。

本版需网页保持打开才能上传结果。关闭网页不影响已提交本机任务，恢复连接后继续回收。浏览器权限、Windows 脚本/协议启动、GPU 仍需实机验收。
