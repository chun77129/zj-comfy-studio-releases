export type ViewTransform={zoom:number;x:number;y:number};
export const fitView:ViewTransform={zoom:1,x:0,y:0};
export function zoomView(view:ViewTransform,factor:number,point:{x:number;y:number}):ViewTransform{
 const zoom=Math.max(.05,Math.min(32,view.zoom*factor)),ratio=zoom/view.zoom;
 return {zoom,x:point.x-(point.x-view.x)*ratio,y:point.y-(point.y-view.y)*ratio};
}
export function fitScale(width:number,height:number,naturalWidth:number,naturalHeight:number){return naturalWidth&&naturalHeight?Math.min(width/naturalWidth,height/naturalHeight):1;}

export type Pane='A'|'B';
export type PaneViews=Record<Pane,ViewTransform>;
export function updatePaneViews(views:PaneViews,pane:Pane,action:ViewTransform|((v:ViewTransform)=>ViewTransform),linked:boolean):PaneViews{
 const apply=(v:ViewTransform)=>typeof action==='function'?action(v):action;
 const other:Pane=pane==='A'?'B':'A';
 return {...views,[pane]:apply(views[pane]),...(linked?{[other]:apply(views[other])}:{})};
}
