import json
import sqlite3
import threading
from pathlib import Path


class Store:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / 'results').mkdir(exist_ok=True)
        self.db = sqlite3.connect(self.root / 'studio.sqlite3', check_same_thread=False)
        self.lock = threading.RLock()
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS records (kind TEXT, id TEXT, value TEXT, PRIMARY KEY(kind,id))')
        self.db.commit()

    def put(self, kind, key, value):
        with self.lock:
            self.db.execute('INSERT OR REPLACE INTO records VALUES (?,?,?)', (kind, key, json.dumps(value, ensure_ascii=False)))
            self.db.commit()
        return value

    def get(self, kind, key, default=None):
        with self.lock:
            row = self.db.execute('SELECT value FROM records WHERE kind=? AND id=?', (kind, key)).fetchone()
        return json.loads(row[0]) if row else default

    def all(self, kind):
        with self.lock:
            rows = self.db.execute('SELECT value FROM records WHERE kind=? ORDER BY rowid DESC', (kind,)).fetchall()
        return [json.loads(row[0]) for row in rows]

    def delete(self, kind, key):
        with self.lock:
            self.db.execute('DELETE FROM records WHERE kind=? AND id=?', (kind, key))
            self.db.commit()
