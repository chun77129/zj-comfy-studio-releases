"""Small atomic receipt shared by the API and its owning restart supervisor."""
import json
from pathlib import Path
import tempfile
import time
import uuid

ACTIVE_PHASES = {'checking', 'downloading', 'receiving', 'verifying', 'extracting', 'waiting_restart', 'applying', 'restarting'}


def read_progress(root):
    try:
        data = json.loads((Path(root) / '.updates/progress.json').read_text('utf-8'))
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def write_progress(root, phase, message, **values):
    previous = {} if values.pop('new', False) else read_progress(root) or {}
    now = time.time()
    history = previous.get('history', [])
    if previous.get('phase') != phase or previous.get('message') != message:
        history = [*history[-19:], {'time': now, 'phase': phase, 'message': message}]
    data = {**previous, 'id': previous.get('id') or str(uuid.uuid4()), 'startedAt': previous.get('startedAt', now),
            'phase': phase, 'message': message, 'updatedAt': now, 'active': phase in ACTIVE_PHASES, 'history': history, **values}
    folder = Path(root) / '.updates'
    folder.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=folder, suffix='.tmp', delete=False) as file:
        json.dump(data, file, ensure_ascii=False)
        temporary = Path(file.name)
    temporary.replace(folder / 'progress.json')
    return data
