import copy
import json
import uuid

from test_studio import rig, ROOT, reconcile
from test_bridge import paired
from backend.workflows import preflight


def test_optional_combo_not_required_and_dynamic_fields_preserved():
    graph = {'1': {'class_type': 'TextGenerate', 'inputs': {'sampling_mode': 'on', 'sampling_mode.temperature': 0.7}}}
    info = {'TextGenerate': {'input': {'required': {'sampling_mode': ['COMFY_DYNAMICCOMBO_V3', {}]}, 'optional': {'mtp': [['auto', 'off']]}}}}
    assert preflight(graph, info) == []
    assert graph['1']['inputs']['sampling_mode.temperature'] == 0.7


def test_official_history_prompt_capture_and_native_png_metadata(rig):
    client, fake, app, _ = rig
    headers, _ = paired(client)
    graph = json.loads((ROOT / 'workflows/krea2-official-api.json').read_text())
    graph['30:19']['inputs']['value'] = '中文原始提示词'
    # Both features enabled, representing a full official execution graph.
    graph['30:23']['inputs']['value'] = True
    graph['30:27']['inputs']['string_b'] = 'monochrome ink wash style'
    for n in graph.values():
        fake.info.setdefault(n['class_type'], {'input': {'required': {}}})
    fake.info['LoraLoaderModelOnly']['input']['required']['lora_name'][0].append('krea2_darkbrush.safetensors')
    native = json.loads((ROOT / 'workflows/krea2-official-full.json').read_text())
    r = client.post('/bridge/jobs', headers=headers, json={'id': str(uuid.uuid4()), 'web_job_id': 'official-web', 'graph': graph, 'workflow': native})
    assert r.status_code == 200, r.text
    job = r.json()
    assert fake.posts[0]['extra_data']['extra_pnginfo']['workflow']['definitions'] == native['definitions']
    assert fake.posts[0]['prompt']['30:16']['inputs']['sampling_mode.temperature'] == 0.7
    fake.finish(job['prompt_id'])
    fake.history[job['prompt_id']]['outputs']['30:20'] = {'text': ['Expanded thunderstorm mountain scene.']}
    done = reconcile(client, app, job)
    assert done['prompt_texts']['original'] == '中文原始提示词'
    assert done['prompt_texts']['final'] == 'Expanded thunderstorm mountain scene., monochrome ink wash style'
    assert done['native_workflow']['id'] == native['id']


def test_missing_text_output_is_not_fabricated(rig):
    client, fake, app, _ = rig
    from test_studio import submit
    job = submit(client).json()
    fake.finish(job['prompt_id'])
    done = reconcile(client, app, job)
    assert 'prompt_texts' not in done
