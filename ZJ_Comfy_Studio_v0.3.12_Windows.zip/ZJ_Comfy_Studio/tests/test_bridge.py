import uuid
from test_studio import rig, GRAPH, reconcile, PNG

SITE = 'https://ai-film-shot-studio.chun77129.chatgpt.site'


def paired(client):
    code = client.post('/api/pairing/code').json()['code']
    r = client.post('/bridge/pair', headers={'origin': SITE}, json={'code': code})
    assert r.status_code == 200
    return {'origin': SITE, 'authorization': 'Bearer '+r.json()['token']}, code


def test_pairing_scoped_cors_one_use_and_revocation(rig):
    c, _, _, _ = rig
    assert c.get('/bridge/health', headers={'origin': 'https://evil.test'}).status_code == 403
    r = c.options('/bridge/jobs', headers={'origin': SITE, 'access-control-request-method': 'POST'})
    assert r.headers['access-control-allow-origin'] == SITE
    assert c.get('/bridge/status', headers={'origin': SITE}).status_code == 401
    headers, code = paired(c)
    assert c.post('/bridge/pair', headers={'origin': SITE}, json={'code': code}).status_code == 401
    assert c.get('/bridge/status', headers=headers).json()['comfyOnline']
    assert c.post('/api/connection', headers=headers, json={'url': 'http://example.test'}).status_code == 403
    c.post('/api/pairing/revoke')
    assert c.get('/bridge/status', headers=headers).status_code == 401


def test_web_job_idempotent_chinese_prompt_and_result_scope(rig):
    c, fake, app, _ = rig
    headers, _ = paired(c)
    graph = __import__('copy').deepcopy(GRAPH)
    graph['6']['inputs']['text'] = '雷雨中的孤峰，天空有清晰闪电'
    body = {'id': str(uuid.uuid4()), 'web_job_id': 'web-001', 'graph': graph}
    first = c.post('/bridge/jobs', headers=headers, json=body)
    assert first.status_code == 200, first.text
    job = first.json()
    assert fake.posts[0]['prompt']['6']['inputs']['text'] == graph['6']['inputs']['text']
    assert c.post('/bridge/jobs', headers=headers, json=body).json()['id'] == job['id']
    assert len(fake.posts) == 1
    graph['6']['inputs']['text'] = '另一条提示词'
    assert c.post('/bridge/jobs', headers=headers, json=body).status_code == 409
    fake.finish(job['prompt_id'])
    done = reconcile(c, app, job)
    assert c.get('/bridge/jobs/'+job['id']+'/results/'+done['results'][0]['file'], headers=headers).content == PNG
    assert c.get('/bridge/jobs/'+job['id']+'/results/other.png', headers=headers).status_code == 404
    assert c.get('/bridge/jobs/'+str(uuid.uuid4()), headers=headers).status_code == 404


def test_wrong_pair_codes_lock_until_local_regeneration(rig):
    c, _, _, _ = rig
    code = c.post('/api/pairing/code').json()['code']
    for _ in range(10):
        assert c.post('/bridge/pair', headers={'origin': SITE}, json={'code': 'invalid'}).status_code == 401
    assert c.post('/bridge/pair', headers={'origin': SITE}, json={'code': code}).status_code == 401
    paired(c)


def test_reference_upload_is_paired_and_content_addressed(rig):
    c, fake, app, _ = rig
    assert c.post('/bridge/uploads', headers={'origin': SITE}, files={'file': ('ref.png', PNG, 'image/png')}).status_code == 401
    headers, _ = paired(c)
    assert c.get('/bridge/status', headers=headers).json()['referenceImages'] is True
    r = c.post('/bridge/uploads', headers=headers, files={'file': ('ref.png', PNG, 'image/png')})
    assert r.status_code == 200, r.text
    assert r.json()['image'] == 'ref.png'
    assert c.post('/bridge/uploads', headers=headers, files={'file': ('bad.txt', b'test', 'text/plain')}).status_code == 422
    assert c.post('/bridge/uploads', headers=headers, files={'file': ('large.png', b'x' * (10*1024*1024+1), 'image/png')}).status_code == 413
    graph = __import__('copy').deepcopy(GRAPH)
    graph['ref'] = {'class_type': 'LoadImage', 'inputs': {'image': r.json()['image']}}
    fake.info['LoadImage'] = {'input': {'required': {}}}
    body = {'id': str(uuid.uuid4()), 'web_job_id': 'web-reference', 'graph': graph}
    result = c.post('/bridge/jobs', headers=headers, json=body)
    assert result.status_code == 200, result.text
    assert fake.posts[0]['prompt']['ref']['inputs']['image'] == 'ref.png'
    assert c.post('/bridge/jobs', headers=headers, json=body).status_code == 200
    assert len(fake.posts) == 1
    fake.finish(result.json()['prompt_id'])
    assert reconcile(c, app, result.json())['status'] == 'completed'
