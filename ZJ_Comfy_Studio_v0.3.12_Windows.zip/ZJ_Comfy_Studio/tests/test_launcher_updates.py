import importlib.util
from pathlib import Path
from types import SimpleNamespace

spec = importlib.util.spec_from_file_location('studio_launcher',Path(__file__).resolve().parents[1]/'scripts/launch.py')
launcher=importlib.util.module_from_spec(spec)
spec.loader.exec_module(launcher)


def test_windows_redirector_pid_difference_accepts_current_instance():
    process=SimpleNamespace(pid=111,studio_instance='a'*32)
    assert launcher.owns_update({'pid':222,'instanceId':'a'*32},process)
    assert not launcher.owns_update({'pid':111,'instanceId':'b'*32},process)
    assert not launcher.owns_update({'pid':111},process)
    assert not launcher.owns_update({'instanceId':None},process)


def test_staging_is_direct_child_and_not_symlink(tmp_path):
    folder=tmp_path/'.updates';folder.mkdir()
    staged=folder/'staged-ok';staged.mkdir()
    assert launcher.valid_staging(tmp_path,'staged-ok')==staged
    for name in [None,'','../staged-ok','staged-ok/..','not-staged','staged-missing']:
        assert launcher.valid_staging(tmp_path,name) is None
    external=tmp_path/'external';external.mkdir();(folder/'staged-link').symlink_to(external,target_is_directory=True)
    assert launcher.valid_staging(tmp_path,'staged-link') is None
