import copy
import json
from pathlib import Path
import pytest
from fastapi import HTTPException
from backend.workflows import canvas_prompt


def spec(required, outputs, output_node=False):
    return {'input': {'required': required}, 'output': outputs, 'output_node': output_node}


def test_mj_canvas():
    raw = json.loads((Path(__file__).parent / 'fixtures/mj-canvas.json').read_text())
    before = copy.deepcopy(raw)
    info = {
        'CLIPLoader': spec({'clip_name': ['COMBO'], 'type': ['COMBO'], 'device': ['COMBO']}, ['CLIP']),
        'UNETLoader': spec({'unet_name': ['COMBO'], 'weight_dtype': ['COMBO']}, ['MODEL']),
        'VAELoader': spec({'vae_name': ['COMBO']}, ['VAE']),
        'EmptyLatentImage': spec({'width': ['INT'], 'height': ['INT'], 'batch_size': ['INT']}, ['LATENT']),
        'CLIPTextEncode': spec({'text': ['STRING'], 'clip': ['CLIP']}, ['CONDITIONING']),
        'CR Prompt Text': spec({'prompt': ['STRING']}, ['STRING', 'STRING']),
        'ResolutionSelector': spec({'aspect_ratio': ['COMBO'], 'megapixels': ['FLOAT'], 'multiple': ['INT']}, ['INT', 'INT']),
        'LoraLoaderModelOnly': spec({'model': ['MODEL'], 'lora_name': ['COMBO'], 'strength_model': ['FLOAT']}, ['MODEL']),
        'ConditioningZeroOut': spec({'conditioning': ['CONDITIONING']}, ['CONDITIONING']),
        'ConditioningKrea2Rebalance': spec({'conditioning': ['CONDITIONING'], 'preset': ['COMBO'], 'per_layer_weights': ['STRING'], 'multiplier': ['FLOAT'], 'renormalize': ['BOOLEAN']}, ['CONDITIONING']),
        'KSampler': spec({'model': ['MODEL'], 'positive': ['CONDITIONING'], 'negative': ['CONDITIONING'], 'latent_image': ['LATENT'], 'seed': ['INT'], 'steps': ['INT'], 'cfg': ['FLOAT'], 'sampler_name': ['COMBO'], 'scheduler': ['COMBO'], 'denoise': ['FLOAT']}, ['LATENT']),
        'VAEDecode': spec({'samples': ['LATENT'], 'vae': ['VAE']}, ['IMAGE']),
        'SaveImage': spec({'images': ['IMAGE'], 'filename_prefix': ['STRING']}, ['STRING', 'IMAGE'], True),
    }
    graph = canvas_prompt(raw, info)
    assert raw == before
    assert len(graph) == 18
    assert graph['202']['inputs']['steps'] == 8
    assert graph['202']['inputs']['cfg'] == 1
    assert graph['199']['inputs']['text'] == ['214', 0]
    assert graph['198']['inputs']['width'] == ['205', 0]
    assert graph['198']['inputs']['height'] == ['205', 1]
    assert len([n for n in graph.values() if n['class_type'] == 'LoraLoaderModelOnly']) == 6
    assert '204' not in graph
    del info['ResolutionSelector']
    with pytest.raises(HTTPException, match='ResolutionSelector'):
        canvas_prompt(raw, info)


def test_real_subgraph_and_broken_link():
    raw = {'nodes': [{'id': 1, 'type': 'nested'}], 'definitions': {'subgraphs': [{'id': 'nested'}]}}
    with pytest.raises(HTTPException, match='子图'):
        canvas_prompt(raw, {'nested': {'output_node': True}})
    raw = {'nodes': [{'id': 1, 'type': 'SaveImage', 'inputs': [{'name': 'images', 'link': 10}]}]}
    with pytest.raises(HTTPException, match='连线无效'):
        canvas_prompt(raw, {'SaveImage': spec({}, [], True)})
